/*
 * arch/arm/include/klibc/archsignal.h
 *
 * Architecture-specific signal definitions
 *
 */

#ifndef _KLIBC_ARCHSIGNAL_H
#define _KLIBC_ARCHSIGNAL_H

/* The in-kernel headers for arm still have libc5
   crap in them.  Reconsider using <asm/signal.h>
   when/if it gets cleaned up; for now, duplicate
   the definitions here. */

#define _NSIG           64
#define _NSIG_BPW       32
#define _NSIG_WORDS     (_NSIG / _NSIG_BPW)

typedef struct {
	unsigned long sig[_NSIG_WORDS];
} sigset_t;

#define SIGHUP		 1
#define SIGINT		 2
#define SIGQUIT		 3
#define SIGILL		 4
#define SIGTRAP		 5
#define SIGABRT		 6
#define SIGIOT		 6
#define SIGBUS		 7
#define SIGFPE		 8
#define SIGKILL		 9
#define SIGUSR1		10
#define SIGSEGV		11
#define SIGUSR2		12
#define SIGPIPE		13
#define SIGALRM		14
#define SIGTERM		15
#define SIGSTKFLT	16
#define SIGCHLD		17
#define SIGCONT		18
#define SIGSTOP		19
#define SIGTSTP		20
#define SIGTTIN		21
#define SIGTTOU		22
#define SIGURG		23
#define SIGXCPU		24
#define SIGXFSZ		25
#define SIGVTALRM	26
#define SIGPROF		27
#define SIGWINCH	28
#define SIGIO		29
#define SIGPOLL		SIGIO
/*
#define SIGLOST		29
*/
#define SIGPWR		30
#define SIGSYS		31
#define	SIGUNUSED	31

/* These should not be considered constants from userland.  */
#define SIGRTMIN	32
#define SIGRTMAX	_NSIG

#define SIGSWI		32

/*
 * SA_FLAGS values:
 *
 * SA_NOCLDSTOP		flag to turn off SIGCHLD when children stop.
 * SA_NOCLDWAIT		flag on SIGCHLD to inhibit zombies.
 * SA_SIGINFO		deliver the signal with SIGINFO structs
 * SA_THIRTYTWO		delivers the signal in 32-bit mode, even if the task
 *			is running in 26-bit.
 * SA_ONSTACK		allows alternate signal stacks (see sigaltstack(2)).
 * SA_RESTART		flag to get restarting signals (which were the default long ago)
 * SA_NODEFER		prevents the current signal from being masked in the handler.
 * SA_RESETHAND		clears the handler when the signal is delivered.
 *
 * SA_ONESHOT and SA_NOMASK are the historical Linux names for the Single
 * Unix names RESETHAND and NODEFER respectively.
 */
#define SA_NOCLDSTOP	0x00000001
#define SA_NOCLDWAIT	0x00000002
#define SA_SIGINFO	0x00000004
#define SA_THIRTYTWO	0x02000000
#define SA_RESTORER	0x04000000
#define SA_ONSTACK	0x08000000
#define SA_RESTART	0x10000000
#define SA_NODEFER	0x40000000
#define SA_RESETHAND	0x80000000

#define SA_NOMASK	SA_NODEFER
#define SA_ONESHOT	SA_RESETHAND


/*
 * sigaltstack controls
 */
#define SS_ONSTACK	1
#define SS_DISABLE	2

#define MINSIGSTKSZ	2048
#define SIGSTKSZ	8192

#include <asm-generic/signal-defs.h>

/* This uses gcc anonymous union support... */
struct siginfo;

struct sigaction {
	union {
		__sighandler_t sa_handler;
		void (*sa_sigaction)(int, struct siginfo *, void *);
	};
	unsigned long	sa_flags;
	__sigrestore_t 	sa_restorer;
	sigset_t	sa_mask;
};

#endif

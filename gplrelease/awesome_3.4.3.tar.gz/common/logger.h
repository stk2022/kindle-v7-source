/*
 * logger.h
 */

#ifndef LOGGER_H_
#define LOGGER_H_

#include <unistd.h>

/* define to enable logging calls */
#define LOGGING_LUA

#ifdef LOGGING_LUA

#define LOGDBG( ...) {\
    lua_getglobal(globalconf.L, "log");\
    if (lua_isfunction(globalconf.L, -1)) {\
        lua_pushfstring(globalconf.L, __VA_ARGS__);\
        lua_pcall(globalconf.L, 1, 0, 0);\
    }\
}

#define LOGPRIVATE( ...) {\
    lua_getglobal(globalconf.L, "log_debug_private");\
    if (lua_isfunction(globalconf.L, -1)) {\
        lua_pushfstring(globalconf.L, __VA_ARGS__);\
        lua_pcall(globalconf.L, 1, 0, 0);\
    }\
}

#define LOGINFO( ...) {\
    lua_getglobal(globalconf.L, "log_info");\
    if (lua_isfunction(globalconf.L, -1)) {\
        lua_pushfstring(globalconf.L, __VA_ARGS__);\
        lua_pcall(globalconf.L, 1, 0, 0);\
    }\
}

#define LOGTIMESTAMP( ...) {\
    lua_getglobal(globalconf.L, "logTimeStamp");\
    if (lua_isfunction(globalconf.L, -1)) {\
        lua_pushfstring(globalconf.L, __VA_ARGS__);\
        lua_pcall(globalconf.L, 1, 0, 0);\
    }\
}

#else

#define LOGINFO(_msg, ...)
#define LOGDBG(_msg, ...)
#define LOGPRIVATE( ...)
#define LOGTIMESTAMP( ...)

#endif

#endif/*#ifndef LOGGER_H_*/

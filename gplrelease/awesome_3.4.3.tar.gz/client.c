/*
 * client.c - client management
 *
 * Copyright  2007-2009 Julien Danjou <julien@danjou.info>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

#include <xcb/xcb_atom.h>
#include <xcb/xcb_image.h>
#ifdef LAB126
#include <cairo/cairo-xcb.h>
#include <xcb/shape.h>
#include <math.h>
#include <sys/shm.h>
#endif

#include "tag.h"
#include "ewmh.h"
#include "screen.h"
#include "titlebar.h"
#include "systray.h"
#include "property.h"
#include "spawn.h"
#include "luaa.h"
#include "common/atoms.h"
#include "common/xutil.h"
#ifdef LAB126
#include "common/logger.h"
#endif

static int client_set_layer_without_restack(client_t * c, int newLayer);

client_t *
luaA_client_checkudata(lua_State *L, int ud)
{
    client_t *c = luaA_checkudata(L, ud, &client_class);
    if(c->invalid)
        luaL_error(L, "client is invalid\n");
    return c;
}

/** Collect a client.
 * \param L The Lua VM state.
 * \return The number of element pushed on stack.
 */
static int
luaA_client_gc(lua_State *L)
{
    client_t *c = luaA_checkudata(L, 1, &client_class);
    button_array_wipe(&c->buttons);
    key_array_wipe(&c->keys);
    xcb_get_wm_protocols_reply_wipe(&c->protocols);
    p_delete(&c->machine);
    p_delete(&c->class);
    p_delete(&c->instance);
    p_delete(&c->icon_name);
    p_delete(&c->alt_icon_name);
    p_delete(&c->name);
    p_delete(&c->alt_name);
    return luaA_object_gc(L);
}

/** Change the client opacity.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param opacity The opacity.
 */
void
client_set_opacity(lua_State *L, int cidx, double opacity)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->opacity != opacity)
    {
        c->opacity = opacity;
        window_opacity_set(c->window, opacity);
        luaA_object_emit_signal(L, cidx, "property::opacity", 0);
    }
}

/** Change the clients urgency flag.
 * \param L The Lua VM state.
 * \param cidx The client index on the stack.
 * \param urgent The new flag state.
 */
void
client_set_urgent(lua_State *L, int cidx, bool urgent)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->urgent != urgent)
    {
        xcb_get_property_cookie_t hints =
            xcb_get_wm_hints_unchecked(globalconf.connection, c->window);

        c->urgent = urgent;
        ewmh_client_update_hints(c);

        /* update ICCCM hints */
        xcb_wm_hints_t wmh;
        xcb_get_wm_hints_reply(globalconf.connection, hints, &wmh, NULL);

        if(urgent)
            wmh.flags |= XCB_WM_HINT_X_URGENCY;
        else
            wmh.flags &= ~XCB_WM_HINT_X_URGENCY;

        xcb_set_wm_hints(globalconf.connection, c->window, &wmh);

        hook_property(c, "urgent");
        luaA_object_emit_signal(L, cidx, "property::urgent", 0);
    }
}

void
client_set_group_window(lua_State *L, int cidx, xcb_window_t window)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->group_window != window)
    {
        c->group_window = window;
        luaA_object_emit_signal(L, cidx, "property::group_window", 0);
    }
}

void
client_set_type(lua_State *L, int cidx, window_type_t type)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->type != type)
    {
        c->type = type;
        luaA_object_emit_signal(L, cidx, "property::type", 0);
    }
}

void
client_set_pid(lua_State *L, int cidx, uint32_t pid)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->pid != pid)
    {
        c->pid = pid;
        luaA_object_emit_signal(L, cidx, "property::pid", 0);
    }
}

void
client_set_icon_name(lua_State *L, int cidx, char *icon_name)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    p_delete(&c->icon_name);
    c->icon_name = icon_name;
    luaA_object_emit_signal(L, cidx, "property::icon_name", 0);
    hook_property(c, "icon_name");
}

void
client_set_alt_icon_name(lua_State *L, int cidx, char *icon_name)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    p_delete(&c->alt_icon_name);
    c->alt_icon_name = icon_name;
    luaA_object_emit_signal(L, cidx, "property::icon_name", 0);
    hook_property(c, "icon_name");
}

void
client_set_role(lua_State *L, int cidx, char *role)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    p_delete(&c->role);
    c->role = role;
    luaA_object_emit_signal(L, cidx, "property::role", 0);
}

void
client_set_machine(lua_State *L, int cidx, char *machine)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    p_delete(&c->machine);
    c->machine = machine;
    luaA_object_emit_signal(L, cidx, "property::machine", 0);
}

void
client_set_class_instance(lua_State *L, int cidx, const char *class, const char *instance)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    p_delete(&c->class);
    p_delete(&c->instance);
    c->class = a_strdup(class);
    c->instance = a_strdup(instance);
    luaA_object_emit_signal(L, cidx, "property::class", 0);
    luaA_object_emit_signal(L, cidx, "property::instance", 0);
}

void
client_set_transient_for(lua_State *L, int cidx, client_t *transient_for)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if (transient_for){
        /** set the has_transient_child flag when a */
        /** parent gets a transient child. This flag indicates */
        /** that the parent may have a transient child and code */
        /** looping through windows to order them should look for them */
        transient_for->has_transient_child = true;
    }

    if(c->transient_for != transient_for)
    {
        c->transient_for = transient_for;
        luaA_object_emit_signal(L, cidx, "property::transient_for", 0);
    }
}

void
client_set_name(lua_State *L, int cidx, char *name)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    p_delete(&c->name);
    c->name = name;
    hook_property(c, "name");
    luaA_object_emit_signal(L, cidx, "property::name", 0);
}

void
client_set_alt_name(lua_State *L, int cidx, char *name)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    p_delete(&c->alt_name);
    c->alt_name = name;
    hook_property(c, "name");
    luaA_object_emit_signal(L, cidx, "property::name", 0);
}

/** Returns true if a client is tagged
 * with one of the tags of the specified screen.
 * \param c The client to check.
 * \param screen Virtual screen.
 * \return true if the client is visible, false otherwise.
 */
bool
client_maybevisible(client_t *c, screen_t *screen)
{
    if(screen && c->screen == screen)
    {
        if(c->sticky || c->type == WINDOW_TYPE_DESKTOP)
            return true;

        foreach(tag, screen->tags)
            if(tag_get_selected(*tag) && is_client_tagged(c, *tag))
                return true;
    }
    return false;
}

/** Get a client by its window.
 * \param w The client window to find.
 * \return A client pointer if found, NULL otherwise.
 */
client_t *
client_getbywin(xcb_window_t w)
{
    foreach(c, globalconf.clients)
        if((*c)->window == w)
            return *c;

    return NULL;
}

/** Record that a client lost focus.
 * \param c Client being unfocused
 */
void
client_unfocus_update(client_t *c)
{
    globalconf.screens.tab[c->phys_screen].client_focus = NULL;
    ewmh_update_net_active_window(c->phys_screen);

    /* Call hook */
    if(globalconf.hooks.unfocus != LUA_REFNIL)
    {
        luaA_object_push(globalconf.L, c);
        luaA_dofunction_from_registry(globalconf.L, globalconf.hooks.unfocus, 1, 0);
    }

    luaA_object_push(globalconf.L, c);
    luaA_class_emit_signal(globalconf.L, &client_class, "unfocus", 1);
}

/** Unfocus a client.
 * \param c The client.
 */
void
client_unfocus(client_t *c)
{

    xcb_window_t root_win = xutil_screen_get(globalconf.connection, c->phys_screen)->root;
    /* Set focus on root window, so no events leak to the current window.
     * This kind of inlines client_set_focus(), but a root window will never have
     * the WM_TAKE_FOCUS protocol.
     */
    xcb_set_input_focus(globalconf.connection, XCB_INPUT_FOCUS_PARENT,
                        root_win, XCB_CURRENT_TIME);

    client_unfocus_update(c);
}

/** Check if client supports atom a protocol in WM_PROTOCOL.
 * \param c The client.
 * \param atom The protocol atom to check for.
 * \return True if client has the atom in protocol, false otherwise.
 */
bool
client_hasproto(client_t *c, xcb_atom_t atom)
{
    for(uint32_t i = 0; i < c->protocols.atoms_len; i++)
        if(c->protocols.atoms[i] == atom)
            return true;
    return false;
}

/** Sets focus on window - using xcb_set_input_focus or WM_TAKE_FOCUS
 * \param c Client that should get focus
 * \param set_input_focus Should we call xcb_set_input_focus
 */
void
client_set_focus(client_t *c, bool set_input_focus)
{
    bool takefocus = client_hasproto(c, WM_TAKE_FOCUS);
    if(set_input_focus)
        xcb_set_input_focus(globalconf.connection, XCB_INPUT_FOCUS_PARENT,
                            c->window, XCB_CURRENT_TIME);
    if(takefocus)
        window_takefocus(c->window);
}

/** Prepare banning a client by running all needed lua events.
 * \param c The client.
 */
void client_ban_unfocus(client_t *c)
{
    if(globalconf.screens.tab[c->phys_screen].prev_client_focus == c)
        globalconf.screens.tab[c->phys_screen].prev_client_focus = NULL;

    /* Wait until the last moment to take away the focus from the window. */
    if(globalconf.screens.tab[c->phys_screen].client_focus == c)
        client_unfocus(c);
}

/** Ban client and move it out of the viewport.
 * \param c The client.
 */
void
client_ban(client_t *c)
{
    if(!c->isbanned)
    {
        xcb_unmap_window(globalconf.connection, c->window);

        c->isbanned = true;

        client_ban_unfocus(c);
    }
}

/** This is part of The Bob Marley Algorithm: we ignore enter and leave window
 * in certain cases, like map/unmap or move, so we don't get spurious events.
 */
void
client_ignore_enterleave_events(void)
{
    foreach(c, globalconf.clients)
        xcb_change_window_attributes(globalconf.connection,
                                     (*c)->window,
                                     XCB_CW_EVENT_MASK,
                                     (const uint32_t []) { CLIENT_SELECT_INPUT_EVENT_MASK & ~(XCB_EVENT_MASK_ENTER_WINDOW | XCB_EVENT_MASK_LEAVE_WINDOW) });
}

void
client_restore_enterleave_events(void)
{
    foreach(c, globalconf.clients)
        xcb_change_window_attributes(globalconf.connection,
                                     (*c)->window,
                                     XCB_CW_EVENT_MASK,
                                     (const uint32_t []) { CLIENT_SELECT_INPUT_EVENT_MASK });
}

/** Record that a client got focus.
 * \param c The client.
 */
void
client_focus_update(client_t *c)
{
    if(!client_maybevisible(c, c->screen))
    {
        /* Focus previously focused client */
        client_focus(globalconf.screen_focus->prev_client_focus);
        return;
    }

    if(globalconf.screen_focus
        && globalconf.screen_focus->client_focus)
    {
        if (globalconf.screen_focus->client_focus != c)
            client_unfocus_update(globalconf.screen_focus->client_focus);
        else
            /* Already focused */
            return;
    }
    luaA_object_push(globalconf.L, c);
    client_set_minimized(globalconf.L, -1, false);

    /* unban the client before focusing for consistency */
    client_unban(c);

    globalconf.screen_focus = &globalconf.screens.tab[c->phys_screen];
    globalconf.screen_focus->prev_client_focus = c;
    globalconf.screen_focus->client_focus = c;

    /* according to EWMH, we have to remove the urgent state from a client */
    client_set_urgent(globalconf.L, -1, false);

#ifdef LAB126
    // pop client
    lua_pop(globalconf.L, 1);
#endif

    ewmh_update_net_active_window(c->phys_screen);

    /* execute hook */
    if(globalconf.hooks.focus != LUA_REFNIL)
    {
        luaA_object_push(globalconf.L, c);
        luaA_dofunction_from_registry(globalconf.L, globalconf.hooks.focus, 1, 0);
    }

    luaA_object_push(globalconf.L, c);
    luaA_class_emit_signal(globalconf.L, &client_class, "focus", 1);
}

/** Give focus to client, or to first client if client is NULL.
 * \param c The client.
 */
void
client_focus(client_t *c)
{
    /* We have to set focus on first client */
    if(!c && globalconf.clients.len && !(c = globalconf.clients.tab[0]))
        return;

    if(!client_maybevisible(c, c->screen))
        return;

    if (!c->nofocus)
        client_focus_update(c);

    client_set_focus(c, !c->nofocus);
}

/**
 * because winmgr is event driven try and validate that the client is still mapped
 * and usable and there is not a pending unmanage coming
 * @params c client to validate
 */
static int
validate_client_window(client_t * c){
    /* init to false */
    int returnVal = 0;

    if (c){
        xcb_get_window_attributes_cookie_t  attributesCookie =
                xcb_get_window_attributes (globalconf.connection, c->window);
        xcb_get_window_attributes_reply_t  *attributes =
                xcb_get_window_attributes_reply (globalconf.connection, attributesCookie, NULL );

        if (attributes){
            /* further validate that the window has a valid map_state*/
            if (attributes->map_state == XCB_MAP_STATE_VIEWABLE){
                /* window is good */
                returnVal = 1;
            } else {
                LOGDBG("window not mapped");
            }
            free(attributes);
        } else {
            LOGDBG("window has no attributes");
        }
    }

    return returnVal;
}

/** Stack a window above.
 * \param c The client.
 * \param previous The previous window on the stack.
 * \return The next-previous!
 */
static xcb_window_t
client_stack_above(client_t *c, xcb_window_t previous)
{
    uint32_t config_win_vals[2];

#ifdef LAB126

    xcb_void_cookie_t cookie;
    if (previous == XCB_NONE){
        LOGDBG("stacking above none");

        config_win_vals[0] = XCB_STACK_MODE_ABOVE;
        cookie = xcb_configure_window_checked(globalconf.connection, c->window,
                                 XCB_CONFIG_WINDOW_STACK_MODE,
                                 config_win_vals);
    } else {
        LOGDBG("stacking %p, above %p", c->window, previous);
        config_win_vals[0] = previous;
        config_win_vals[1] = XCB_STACK_MODE_ABOVE;
        cookie = xcb_configure_window_checked(globalconf.connection, c->window,
                         XCB_CONFIG_WINDOW_SIBLING | XCB_CONFIG_WINDOW_STACK_MODE,
                         config_win_vals);
    }

    if (xcb_request_check(globalconf.connection, cookie)) {

        /* one possible reason for the fail is that the window we are stacking has been destroyed */
        /* if so, we need do nothing. But if the window is still around, fall back on a full restack */
        if (validate_client_window(c)){
            LOGINFO("stack above failed, falling back on restack");
            client_stack();
        } else {
            LOGINFO("stack above failed because window has become invalid");
        }

    } else {
        LOGDBG("stack above worked");
    }

    previous = c->window;

#else
    config_win_vals[0] = previous;
    config_win_vals[1] = XCB_STACK_MODE_ABOVE;
    xcb_configure_window(globalconf.connection, c->window,
                     XCB_CONFIG_WINDOW_SIBLING | XCB_CONFIG_WINDOW_STACK_MODE,
                     config_win_vals);

#endif
    config_win_vals[0] = c->window;

    if(c->titlebar)
    {
        xcb_configure_window(globalconf.connection,
                             c->titlebar->window,
                             XCB_CONFIG_WINDOW_SIBLING | XCB_CONFIG_WINDOW_STACK_MODE,
                             config_win_vals);

        previous = c->titlebar->window;
    }
    else
        previous = c->window;

    if (c->has_transient_child){
        /* stack transient window on top of their parents */
        foreach(node, globalconf.stack)
            if((*node)->transient_for == c){
                LOGDBG("stack transient");
                previous = client_stack_above(*node, previous);
            }
    }

    return previous;
}

#ifdef LAB126
/** Stack a window below.
 * \param c The client.
 * \param previous The previous window on the stack.
 * \return The next-previous!
 */
static xcb_window_t
client_stack_below(client_t *c, xcb_window_t previous)
{

    uint32_t config_win_vals[2];

    /* stack transient window on top of their parents */
    if (c->has_transient_child){
        reverse_foreach(node, globalconf.stack)
            if((*node)->transient_for == c){
                previous = client_stack_below(*node, previous);
            }
    }

    xcb_void_cookie_t cookie;

    if(previous == XCB_NONE){
        /* Below none means on bottom */
        config_win_vals[0] = XCB_STACK_MODE_BELOW;
        cookie = xcb_configure_window_checked(globalconf.connection, c->window,
                         XCB_CONFIG_WINDOW_STACK_MODE,
                         config_win_vals);
    } else {
        config_win_vals[0] = previous;
        config_win_vals[1] = XCB_STACK_MODE_BELOW;
        cookie = xcb_configure_window_checked(globalconf.connection, c->window,
                         XCB_CONFIG_WINDOW_SIBLING | XCB_CONFIG_WINDOW_STACK_MODE,
                         config_win_vals);
    }

    if (xcb_request_check(globalconf.connection, cookie)) {
        LOGINFO("stack below failed, falling back on restack");
        
        /* one possible reason for the fail is that the window we are stacking has been destroyed */
        /* if so, we need do nothing. But if the window is still around, fall back on a full restack */
        xcb_get_window_attributes_cookie_t  attributesCookie = xcb_get_window_attributes (globalconf.connection, c->window);
        xcb_get_window_attributes_reply_t  *attributes = xcb_get_window_attributes_reply (globalconf.connection,
                                                                                                attributesCookie,
                                                                                                NULL );
        if (attributes){
            client_stack();
            free(attributes);
        } else {
            LOGINFO("ignoring failed stack attempt because window does not exist");
        }
    } else {
        LOGDBG("stack below worked");
    }

    return c->window;
}
#endif

/** Stacking layout layers */
typedef enum
{
    /** This one is a special layer */
    LAYER_IGNORE,
    LAYER_DESKTOP,
#ifdef LAB126
    LAYER_HIDDEN,
#endif
    LAYER_BELOW,
    LAYER_NORMAL,
    LAYER_ABOVE,
#ifdef LAB126
    LAYER_DIALOG,
    LAYER_KB,
    LAYER_ALERT,
#endif
    LAYER_FULLSCREEN,
    LAYER_ONTOP,
    /** This one only used for counting and is not a real layer */
    LAYER_COUNT
} layer_t;

/** Get the real layer of a client according to its attribute (fullscreen, )
 * \param c The client.
 * \return The real layer.
 */
static layer_t
client_layer_translator(client_t *c)
{
#ifdef LAB126
    /* check for transient attr */
    /* do this before checking layers */
    if(c->transient_for)
        return LAYER_IGNORE;
#endif

    /* first deal with user set attributes */
    if(c->ontop)
        return LAYER_ONTOP;
    else if(c->fullscreen)
        return LAYER_FULLSCREEN;
    else if(c->above)
        return LAYER_ABOVE;
    else if(c->below)
        return LAYER_BELOW;
#ifdef LAB126
    else if (c->hiddenLayer)
        return LAYER_HIDDEN;
    else if (c->dialogLayer)
        return LAYER_DIALOG;
    else if (c->kbLayer)
        return LAYER_KB;
    else if (c->alertLayer)
        return LAYER_ALERT;
#endif

#ifndef LAB126
    /* check for transient attr */
    if(c->transient_for)
        return LAYER_IGNORE;
#endif

    /* then deal with windows type */
    switch(c->type)
    {
      case WINDOW_TYPE_DESKTOP:
        return LAYER_DESKTOP;
      default:
        break;
    }

    return LAYER_NORMAL;
}

#ifdef LAB126
int
client_stack_refresh(){
    if (!globalconf.client_need_stack_refresh)
        return 0;

    layer_t layer;

    xcb_window_t previous = XCB_NONE;

    /*
     * layer up from middle showing visible clients
     */
    xcb_window_t separator = XCB_NONE;
    /* loop up from below layer layering each client up */
    for(layer = LAYER_BELOW; layer < LAYER_COUNT; layer++){
        LOGDBG("+++++layering client layer %d\n", layer);
        foreach(node, globalconf.stack){
            client_t* c = *node;
            if(client_layer_translator(c) == layer){
                /* save the middle separator we layer up from */
                /* to layer all the hidden clients below */
                if (separator == XCB_NONE){
                    separator = c->window;
                }
                LOGDBG ("+++++ +++++layering client %p :: %s\n", c->window, c->alt_name);
                previous = client_stack_above(c, previous);
            }
        }
        LOGDBG("-----layering client layer %d\n", layer);
    }

    LOGDBG("layering hidden layers");

    /* layer lower non visible clients below separator */
    previous = separator;
    for(layer = LAYER_BELOW - 1; layer >= LAYER_HIDDEN; layer--){
        LOGDBG("+++++layering client layer %d\n", layer);
        reverse_foreach(node, globalconf.stack){
            client_t* c = *node;
            if(client_layer_translator(c) == layer){
                LOGDBG ("+++++ +++++layering client %p :: %s\n", c->window, c->alt_name);
                previous = client_stack_below(c, previous);
            }
        }
        LOGDBG("-----layering client layer %d\n", layer);
    }

    globalconf.client_need_stack_refresh = false;

    return 1;
}

#else
/** Restack clients.
 * \todo It might be worth stopping to restack everyone and only stack `c'
 * relatively to the first matching in the list.
 */
void
client_stack_refresh()
{
    uint32_t config_win_vals[2];
    layer_t layer;

    if (!globalconf.client_need_stack_refresh)
        return;

    globalconf.client_need_stack_refresh = false;

    config_win_vals[0] = XCB_NONE;
    config_win_vals[1] = XCB_STACK_MODE_ABOVE;

    /* stack desktop windows */
    for(layer = LAYER_DESKTOP; layer < LAYER_BELOW; layer++){
        foreach(node, globalconf.stack){
            client_t* c = *node;
            if(client_layer_translator(c) == layer){
                config_win_vals[0] = client_stack_above(*node,
                                                        config_win_vals[0]);
            }
        }
    }

    /* first stack not ontop wibox window */
    foreach(_sb, globalconf.wiboxes)
    {
        wibox_t *sb = *_sb;
        if(!sb->ontop)
        {
            LOGDBG("here %p\n", sb->window);
            xcb_configure_window(globalconf.connection,
                                 sb->window,
                                 XCB_CONFIG_WINDOW_SIBLING | XCB_CONFIG_WINDOW_STACK_MODE,
                                 config_win_vals);
            config_win_vals[0] = sb->window;
        }
    }

    /* then stack clients */
    for(layer = LAYER_BELOW; layer < LAYER_COUNT; layer++){
        foreach(node, globalconf.stack){
            client_t* c = *node;
            if(client_layer_translator(c) == layer){
                config_win_vals[0] = client_stack_above(c,
                                                        config_win_vals[0]);
            }
        }
    }

    /* then stack ontop wibox window */
    foreach(_sb, globalconf.wiboxes)
    {
        wibox_t *sb = *_sb;
        if(sb->ontop)
        {
            LOGDBG("ontop wiboxr %p\n", sb->window);
            xcb_configure_window(globalconf.connection,
                                 sb->window,
                                 XCB_CONFIG_WINDOW_SIBLING | XCB_CONFIG_WINDOW_STACK_MODE,
                                 config_win_vals);
            config_win_vals[0] = sb->window;
        }
    }
}
#endif

#ifdef LAB126
/* It might make more sense to move the below to a separate file and make */
/* custom client message handling on LUA side more official */
/* doing it here is a bit more low touch and does not require any changes */
/* to the make open source make files */

#define HANDLABLE_ATOM_PREFIX       "lab126_"
#define HANDLABLE_ATOM_PREFIX_LEN   7

/* client message data field is 20 bytes */
#define MAX_SIZE_MESSAGE_DATA       20

/* struct to allow LUA to read through client message */
/* data and convert */
typedef struct {
    uint8_t* data;
    int pos;
}ClientMessageData;

/* util macro to generate getters */
#define CLIENT_MESSAGET_GET(type_t) \
    static int \
    client_message_get_##type_t(lua_State* L){ \
        ClientMessageData* temp = (ClientMessageData*) lua_touserdata (L, 1); \
        if ((temp->pos + sizeof(type_t))> MAX_SIZE_MESSAGE_DATA){ \
            LOGINFO("can not over run user data field"); \
            return 0; \
        } \
        /* get first element at pos and cast to type_t */ \
        type_t value = ((type_t*)(temp->data + temp->pos))[0]; \
        temp->pos += sizeof(type_t); \
        lua_pushnumber (L, value); \
        return 1; \
    }

/* util macro to generate setters */
#define CLIENT_MESSAGET_SET(type_t) \
    static int \
    client_message_set_##type_t(lua_State* L){ \
        ClientMessageData* temp = (ClientMessageData*) lua_touserdata (L, 1); \
        type_t value = (type_t)luaL_checkinteger(L, 2); \
        LOGDBG("client message set size=%d value=%d ptr=%p data=%p pos=%d", \
                sizeof(type_t), value, temp, temp->data, temp->pos); \
        if ((temp->pos + sizeof(type_t))> MAX_SIZE_MESSAGE_DATA){ \
            LOGINFO("can not over run user data field"); \
            return 0; \
        } \
        /* cast to type_t and set first element at pos */ \
        ((type_t*)(temp->data + temp->pos))[0] = value; \
        temp->pos += sizeof(type_t); \
        return 0; \
    }

/* generate getters and setters */
CLIENT_MESSAGET_GET(uint8_t)
CLIENT_MESSAGET_GET(uint16_t)
CLIENT_MESSAGET_GET(uint32_t)
CLIENT_MESSAGET_SET(uint8_t)
CLIENT_MESSAGET_SET(uint16_t)
CLIENT_MESSAGET_SET(uint32_t)

/**
 * set read position in data to specific byte offset
 */
static int client_message_set_pos(lua_State* L){
    ClientMessageData* temp = (ClientMessageData*) lua_touserdata (L, 1);
    int newPos = luaL_checknumber(L, 2);

    if (newPos>MAX_SIZE_MESSAGE_DATA || newPos<0){
        LOGDBG("can not over/under run user data field");
        return 0;
    }

    LOGDBG("setting client message data pos = %d", newPos);
    temp->pos = newPos;
    return 0;
}

/**
 * Allocate a ClientMessageData.
 * The calling code owns the memory and must free it with client_message_free.
 */
static int client_message_alloc(lua_State* L){
    ClientMessageData* data = malloc(sizeof(ClientMessageData));
    if (data) {
        data->pos = 0;
        data->data = malloc(MAX_SIZE_MESSAGE_DATA);
        if (data->data) {
            memset(data->data, 0, MAX_SIZE_MESSAGE_DATA);
            // return data to Lua
            lua_pushlightuserdata(L, (void*)data);
            LOGDBG("allocated client message data %p %p %d", data, data->data, data->pos);
            return 1;
        } else {
            LOGINFO("failed to allocate client message data array");
            free(data);
        }
    }
    // return nil to Lua
    LOGINFO("failed to allocate client message data");
    lua_pushnil(L);
    return 1;
}

static int client_message_free(lua_State* L){
    ClientMessageData* data = (ClientMessageData*) lua_touserdata(L, 1);
    if (data) {
        free(data->data);
        free(data);
    } else {
        LOGINFO("client_message_free: null data");
    }
    return 0;
}

static int client_message_send(lua_State* L){
    size_t name_len;
    client_t *c = luaA_client_checkudata(L, 1);
    const char *name = luaL_checklstring(L, 2, &name_len);
    ClientMessageData *data = (ClientMessageData*)lua_touserdata(L, 3);

    if (c && name && name_len > 0 && data) {
        xcb_client_message_event_t ev;
        xcb_intern_atom_reply_t *atom_reply;
        xcb_intern_atom_cookie_t atom_cookie =
            xcb_intern_atom(globalconf.connection, 0, name_len, name);

        /* Initialize all of event's fields first */
        p_clear(&ev, 1);

        ev.response_type = XCB_CLIENT_MESSAGE;
        ev.window = c->window;
        ev.format = 8;
        LOGDBG("client_message_send c=%s msg=%s data=(%p %p %p %p %p)",
                c->alt_name,
                name,
                ((unsigned int *)data->data)[0],
                ((unsigned int *)data->data)[1],
                ((unsigned int *)data->data)[2],
                ((unsigned int *)data->data)[3],
                ((unsigned int *)data->data)[4]);
        memcpy(ev.data.data8, data->data, MAX_SIZE_MESSAGE_DATA);
        atom_reply = xcb_intern_atom_reply(globalconf.connection, atom_cookie, NULL);
        if (atom_reply) {
            ev.type = atom_reply->atom;
            xcb_send_event(globalconf.connection, false, c->window,
                    XCB_EVENT_MASK_NO_EVENT, (char *) &ev);
        } else {
            LOGINFO("failed to intern atom %s; cannot send client message", name);
        }
    } else {
        LOGINFO("invalid parameter to client_message_send");
    }
    return 0;
}

static const struct luaL_Reg clientData [] = {
        {"get_uint8", client_message_get_uint8_t},
        {"get_uint16", client_message_get_uint16_t},
        {"get_uint32", client_message_get_uint32_t},
        {"set_uint8", client_message_set_uint8_t},
        {"set_uint16", client_message_set_uint16_t},
        {"set_uint32", client_message_set_uint32_t},
        {"set_pos", client_message_set_pos},
        {"alloc", client_message_alloc},
        {"free", client_message_free},
        {"send", client_message_send},
        {NULL, NULL}
};

/**
 * Handle client message
 * @params c            : client which client message event was attached to
 * @params atomName     : non NULL terminated string name of atom
 * @params atomNameLen  : len of atomName string
 * @params data         : 20 byte client message data. Data struct diff per message type.
 */
int
client_message(client_t* c, const char* atomName, int atomNameLen, uint8_t* data)
{
    LOGDBG("+++++ client_message");

    /* check params*/
    if ( !c || !atomName || (atomNameLen == 0) || (data == NULL) ){
        return 0;
    }

    int returnVal = 0;

    /* hard coding custom client messages handled as */
    /* beginning with "lab126_" for simplicity. It would be better */
    /* allow LUA side to register for specific atomNames and/or */
    /* prefixes */
    if ( (atomNameLen > HANDLABLE_ATOM_PREFIX_LEN) &&
            (strncmp(atomName, HANDLABLE_ATOM_PREFIX, HANDLABLE_ATOM_PREFIX_LEN) == 0) ){

        /* considering any LAB126 client message as handled */
        returnVal = 1;

        /* atomName is not NULL terminated */
        char* strNameLocalCpy = malloc((atomNameLen + 1) * sizeof(char));
        if (strNameLocalCpy){
            strncpy(strNameLocalCpy, atomName, atomNameLen);
            strNameLocalCpy[atomNameLen] = 0;
            LOGDBG("custom client message win=%s, atom=%s", c->alt_name, strNameLocalCpy);

            /* ClientMessageData object for LUA to read Custom Data */
            ClientMessageData clientMessageData;
            clientMessageData.pos = 0;
            clientMessageData.data = data;

            /* client is still on top of the stack; push startup value,
             * and emit signals with 2 args */
            luaA_object_push(globalconf.L, c);
            lua_pushstring(globalconf.L, strNameLocalCpy);
            lua_pushlightuserdata (globalconf.L, (void*)&clientMessageData);
            luaA_class_emit_signal(globalconf.L, &client_class, "message", 3);

            free(strNameLocalCpy);
        }
    }

    LOGDBG("---- client_message");

    return returnVal;
}
#endif

/** Manage a new client.
 * \param w The window.
 * \param wgeom Window geometry.
 * \param phys_screen Physical screen number.
 * \param startup True if we are managing at startup time.
 */
void
client_manage(xcb_window_t w, xcb_get_geometry_reply_t *wgeom, int phys_screen, bool startup)
{
    const uint32_t select_input_val[] = { CLIENT_SELECT_INPUT_EVENT_MASK };

    if(systray_iskdedockapp(w))
    {
        systray_request_handle(w, phys_screen, NULL);
        return;
    }

    /* If this is a new client that just has been launched, then request its
     * startup id. */
    xcb_get_property_cookie_t startup_id_q = { 0 };
    if(!startup)
        startup_id_q = xcb_get_any_property(globalconf.connection,
                                            false, w, _NET_STARTUP_ID, UINT_MAX);

    xcb_change_window_attributes(globalconf.connection, w, XCB_CW_EVENT_MASK, select_input_val);

    client_t *c = client_new(globalconf.L);

    /* This cannot change, ever. */
    c->phys_screen = phys_screen;
    /* consider the window banned */
    c->isbanned = true;
    /* Store window */
    c->window = w;
    luaA_object_emit_signal(globalconf.L, -1, "property::window", 0);

    /* Duplicate client and push it in client list */
    lua_pushvalue(globalconf.L, -1);
    client_array_push(&globalconf.clients, luaA_object_ref(globalconf.L, -1));

    /* Set the right screen */
    screen_client_moveto(c, screen_getbycoord(&globalconf.screens.tab[phys_screen], wgeom->x, wgeom->y), false);

    /* Store initial geometry and emits signals so we inform that geometry have
     * been set. */
#define HANDLE_GEOM(attr) \
    c->geometry.attr = wgeom->attr; \
    c->geometries.internal.attr = wgeom->attr; \
    luaA_object_emit_signal(globalconf.L, -1, "property::" #attr, 0);
HANDLE_GEOM(x)
HANDLE_GEOM(y)
HANDLE_GEOM(width)
HANDLE_GEOM(height)
#undef HANDLE_GEOM

    luaA_object_emit_signal(globalconf.L, -1, "property::geometry", 0);

    /* Push client */
    client_set_border_width(globalconf.L, -1, wgeom->border_width);

    /* we honor size hints by default */
    c->size_hints_honor = true;
    luaA_object_emit_signal(globalconf.L, -1, "property::size_hints_honor", 0);

    /* update hints */
    property_update_wm_normal_hints(c, NULL);
    property_update_wm_hints(c, NULL);
    property_update_wm_transient_for(c, NULL);
    property_update_wm_client_leader(c, NULL);
    property_update_wm_client_machine(c, NULL);
    property_update_wm_window_role(c, NULL);
    property_update_net_wm_pid(c, NULL);
    property_update_net_wm_icon(c, NULL);

    /* get opacity */
    client_set_opacity(globalconf.L, -1, window_opacity_get(c->window));

    /* Then check clients hints */
    ewmh_client_check_hints(c);

#ifndef LAB126
    /* Push client in stack */
    client_raise(c);
#endif

    /* update window title */
    property_update_wm_name(c, NULL);
    property_update_net_wm_name(c, NULL);
    property_update_wm_icon_name(c, NULL);
    property_update_net_wm_icon_name(c, NULL);
    property_update_wm_class(c, NULL);
    property_update_wm_protocols(c, NULL);

    /* update strut */
    ewmh_process_client_strut(c, NULL);

    ewmh_update_net_client_list(c->phys_screen);

    /* Always stay in NORMAL_STATE. Even though iconified seems more
     * appropriate sometimes. The only possible loss is that clients not using
     * visibility events may continue to process data (when banned).
     * Without any exposes or other events the cost should be fairly limited though.
     *
     * Some clients may expect the window to be unmapped when STATE_ICONIFIED.
     * Two conflicting parts of the ICCCM v2.0 (section 4.1.4):
     *
     * "Normal -> Iconic - The client should send a ClientMessage event as described later in this section."
     * (note no explicit mention of unmapping, while Normal->Widthdrawn does mention that)
     *
     * "Once a client's window has left the Withdrawn state, the window will be mapped
     * if it is in the Normal state and the window will be unmapped if it is in the Iconic state."
     *
     * At this stage it's just safer to keep it in normal state and avoid confusion.
     */
    window_state_set(c->window, XCB_WM_STATE_NORMAL);

    if(!startup)
    {
        /* Request our response */
        xcb_get_property_reply_t *reply =
            xcb_get_property_reply(globalconf.connection, startup_id_q, NULL);
        /* Say spawn that a client has been started, with startup id as argument */
        char *startup_id = xutil_get_text_property_from_reply(reply);
        p_delete(&reply);
        spawn_start_notify(c, startup_id);
        p_delete(&startup_id);
    }

    /* Call hook to notify list change */
    if(globalconf.hooks.clients != LUA_REFNIL)
        luaA_dofunction_from_registry(globalconf.L, globalconf.hooks.clients, 0, 0);

    luaA_class_emit_signal(globalconf.L, &client_class, "list", 0);

    /* call hook */
    if(globalconf.hooks.manage != LUA_REFNIL)
    {
        luaA_object_push(globalconf.L, c);
        lua_pushboolean(globalconf.L, startup);
        luaA_dofunction_from_registry(globalconf.L, globalconf.hooks.manage, 2, 0);
    }

#ifdef LAB126
    /*
        Move window to the bottom of the stack initially to not obscure other windows.
        Correct stacking order will be calculated later.
    */

    client_set_layer_without_restack(c, LAYER_HIDDEN);

    /* create damage id */
    c->damage = xcb_generate_id(globalconf.connection);
    xcb_damage_create(globalconf.connection, c->damage, c->window,
            XCB_DAMAGE_REPORT_LEVEL_BOUNDING_BOX);
#endif

    /* client is still on top of the stack; push startup value,
     * and emit signals with 2 args */
    lua_pushboolean(globalconf.L, startup);
    luaA_class_emit_signal(globalconf.L, &client_class, "manage", 2);
}

#ifdef LAB126
void
client_emit_stack_updated_signal()
{
    luaA_class_emit_signal(globalconf.L, &client_class, "clientStackUpdated", 0);
}
#endif

/** Compute client geometry with respect to its geometry hints.
 * \param c The client.
 * \param geometry The geometry that the client might receive.
 * \return The geometry the client must take respecting its hints.
 */
area_t
client_geometry_hints(client_t *c, area_t geometry)
{
    int32_t basew, baseh, minw, minh;

    /* base size is substituted with min size if not specified */
    if(c->size_hints.flags & XCB_SIZE_HINT_P_SIZE)
    {
        basew = c->size_hints.base_width;
        baseh = c->size_hints.base_height;
    }
    else if(c->size_hints.flags & XCB_SIZE_HINT_P_MIN_SIZE)
    {
        basew = c->size_hints.min_width;
        baseh = c->size_hints.min_height;
    }
    else
        basew = baseh = 0;

    /* min size is substituted with base size if not specified */
    if(c->size_hints.flags & XCB_SIZE_HINT_P_MIN_SIZE)
    {
        minw = c->size_hints.min_width;
        minh = c->size_hints.min_height;
    }
    else if(c->size_hints.flags & XCB_SIZE_HINT_P_SIZE)
    {
        minw = c->size_hints.base_width;
        minh = c->size_hints.base_height;
    }
    else
        minw = minh = 0;

    if(c->size_hints.flags & XCB_SIZE_HINT_P_ASPECT
       && c->size_hints.min_aspect_num > 0
       && c->size_hints.min_aspect_den > 0
       && geometry.height - baseh > 0
       && geometry.width - basew > 0)
    {
        double dx = (double) (geometry.width - basew);
        double dy = (double) (geometry.height - baseh);
        double min = (double) c->size_hints.min_aspect_num / (double) c->size_hints.min_aspect_den;
        double max = (double) c->size_hints.max_aspect_num / (double) c->size_hints.min_aspect_den;
        double ratio = dx / dy;
        if(max > 0 && min > 0 && ratio > 0)
        {
            if(ratio < min)
            {
                dy = (dx * min + dy) / (min * min + 1);
                dx = dy * min;
                geometry.width = (int) dx + basew;
                geometry.height = (int) dy + baseh;
            }
            else if(ratio > max)
            {
                dy = (dx * min + dy) / (max * max + 1);
                dx = dy * min;
                geometry.width = (int) dx + basew;
                geometry.height = (int) dy + baseh;
            }
        }
    }

    if(minw)
        geometry.width = MAX(geometry.width, minw);
    if(minh)
        geometry.height = MAX(geometry.height, minh);

    if(c->size_hints.flags & XCB_SIZE_HINT_P_MAX_SIZE)
    {
        if(c->size_hints.max_width)
            geometry.width = MIN(geometry.width, c->size_hints.max_width);
        if(c->size_hints.max_height)
            geometry.height = MIN(geometry.height, c->size_hints.max_height);
    }

    if(c->size_hints.flags & (XCB_SIZE_HINT_P_RESIZE_INC | XCB_SIZE_HINT_BASE_SIZE)
       && c->size_hints.width_inc && c->size_hints.height_inc)
    {
        uint16_t t1 = geometry.width, t2 = geometry.height;
        unsigned_subtract(t1, basew);
        unsigned_subtract(t2, baseh);
        geometry.width -= t1 % c->size_hints.width_inc;
        geometry.height -= t2 % c->size_hints.height_inc;
    }

    return geometry;
}

/** Resize client window.
 * The sizes given as parameters are with titlebar and borders!
 * \param c Client to resize.
 * \param geometry New window geometry.
 * \param hints Use size hints.
 * \return true if an actual resize occurred.
 */
#ifdef LAB126
bool
client_resize(client_t *c, area_t geometry, bool hints)
{
    area_t geometry_internal;
    area_t area;

    /* offscreen appearance fixes */
    area = screen_area_get(c->screen, false);

    if(geometry.x > area.width)
        geometry.x = area.width - geometry.width;
    if(geometry.y > area.height)
        geometry.y = area.height - geometry.height;
    if(geometry.x + geometry.width < 0)
        geometry.x = 0;
    if(geometry.y + geometry.height < 0)
        geometry.y = 0;

    /* Real client geometry, please keep it contained to C code at the very least. */
    geometry_internal = titlebar_geometry_remove(c->titlebar, c->border_width, geometry);

    if(hints)
        geometry_internal = client_geometry_hints(c, geometry_internal);

    if(geometry_internal.width == 0 || geometry_internal.height == 0)
        return false;

    /* Also let client hints propagate to the "official" geometry. */
    geometry = titlebar_geometry_add(c->titlebar, c->border_width, geometry_internal);

    if(c->geometries.internal.x != geometry_internal.x
       || c->geometries.internal.y != geometry_internal.y
       || c->geometries.internal.width != geometry_internal.width
       || c->geometries.internal.height != geometry_internal.height)
    {
        screen_t *new_screen = screen_getbycoord(c->screen,
                                                 geometry_internal.x, geometry_internal.y);

        area_t old_geometry = c->geometries.internal;

        c->geometries.internal.x = geometry_internal.x;
        c->geometries.internal.y = geometry_internal.y;
        c->geometries.internal.width = geometry_internal.width;
        c->geometries.internal.height = geometry_internal.height;

        /* Also store geometry including border and titlebar. */
        c->geometry = geometry;

        titlebar_update_geometry(c);

        screen_client_moveto(c, new_screen, false);

        /* execute hook */
        hook_property(c, "geometry");

        luaA_object_push(globalconf.L, c);
        luaA_object_emit_signal(globalconf.L, -1, "property::geometry", 0);
        /** \todo This need to be VERIFIED before it is emitted! */
        luaA_object_emit_signal(globalconf.L, -1, "property::x", 0);
        luaA_object_emit_signal(globalconf.L, -1, "property::y", 0);
        luaA_object_emit_signal(globalconf.L, -1, "property::width", 0);
        luaA_object_emit_signal(globalconf.L, -1, "property::height", 0);
        lua_pop(globalconf.L, 1);

        if (c->geometries.internal.x != old_geometry.x
            || c->geometries.internal.y != old_geometry.y
            || c->geometries.internal.width != old_geometry.width
            || c->geometries.internal.height != old_geometry.height)
        {
            /* Values to configure a window is an array where values are
             * stored according to 'value_mask' */
            uint32_t values[4];
            values[0] = c->geometries.internal.x;
            values[1] = c->geometries.internal.y;
            values[2] = c->geometries.internal.width;
            values[3] = c->geometries.internal.height;

            /* Ignore all spurious enter/leave notify events */
            client_ignore_enterleave_events();

            xcb_configure_window(globalconf.connection, c->window,
                             XCB_CONFIG_WINDOW_X | XCB_CONFIG_WINDOW_Y
                             | XCB_CONFIG_WINDOW_WIDTH | XCB_CONFIG_WINDOW_HEIGHT,
                             values);

            client_restore_enterleave_events();

            return true;
        }
    }

    return false;
}
#else
bool
client_resize(client_t *c, area_t geometry, bool hints)
{
    area_t geometry_internal;
    area_t area;

    /* offscreen appearance fixes */
    area = display_area_get(c->phys_screen);

    if(geometry.x > area.width)
        geometry.x = area.width - geometry.width;
    if(geometry.y > area.height)
        geometry.y = area.height - geometry.height;
    if(geometry.x + geometry.width < 0)
        geometry.x = 0;
    if(geometry.y + geometry.height < 0)
        geometry.y = 0;

    /* Real client geometry, please keep it contained to C code at the very least. */
    geometry_internal = titlebar_geometry_remove(c->titlebar, c->border_width, geometry);

    if(hints)
        geometry_internal = client_geometry_hints(c, geometry_internal);

    if(geometry_internal.width == 0 || geometry_internal.height == 0)
        return false;

    /* Also let client hints propagate to the "official" geometry. */
    geometry = titlebar_geometry_add(c->titlebar, c->border_width, geometry_internal);

    if(c->geometries.internal.x != geometry_internal.x
       || c->geometries.internal.y != geometry_internal.y
       || c->geometries.internal.width != geometry_internal.width
       || c->geometries.internal.height != geometry_internal.height)
    {
        screen_t *new_screen = screen_getbycoord(c->screen,
                                                 geometry_internal.x, geometry_internal.y);

        /* Values to configure a window is an array where values are
         * stored according to 'value_mask' */
        uint32_t values[4];

        c->geometries.internal.x = values[0] = geometry_internal.x;
        c->geometries.internal.y = values[1] = geometry_internal.y;
        c->geometries.internal.width = values[2] = geometry_internal.width;
        c->geometries.internal.height = values[3] = geometry_internal.height;

        /* Also store geometry including border and titlebar. */
        c->geometry = geometry;

        titlebar_update_geometry(c);

        /* Ignore all spurious enter/leave notify events */
        client_ignore_enterleave_events();

        xcb_configure_window(globalconf.connection, c->window,
                             XCB_CONFIG_WINDOW_X | XCB_CONFIG_WINDOW_Y
                             | XCB_CONFIG_WINDOW_WIDTH | XCB_CONFIG_WINDOW_HEIGHT,
                             values);

        client_restore_enterleave_events();

        screen_client_moveto(c, new_screen, false);

        /* execute hook */
        hook_property(c, "geometry");

        luaA_object_push(globalconf.L, c);
        luaA_object_emit_signal(globalconf.L, -1, "property::geometry", 0);
        /** \todo This need to be VERIFIED before it is emitted! */
        luaA_object_emit_signal(globalconf.L, -1, "property::x", 0);
        luaA_object_emit_signal(globalconf.L, -1, "property::y", 0);
        luaA_object_emit_signal(globalconf.L, -1, "property::width", 0);
        luaA_object_emit_signal(globalconf.L, -1, "property::height", 0);
        lua_pop(globalconf.L, 1);

        return true;
    }

    return false;
}
#endif

/** Set a client minimized, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client minimized.
 */
void
client_set_minimized(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->minimized != s)
    {
        c->minimized = s;
        banning_need_update((c)->screen);
        if(s)
            window_state_set(c->window, XCB_WM_STATE_ICONIC);
        else
            window_state_set(c->window, XCB_WM_STATE_NORMAL);
        ewmh_client_update_hints(c);
        if(strut_has_value(&c->strut))
            screen_emit_signal(globalconf.L, c->screen, "property::workarea", 0);
        /* execute hook */
        hook_property(c, "minimized");
        luaA_object_emit_signal(L, cidx, "property::minimized", 0);
    }
}

/** Set a client sticky, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client sticky.
 */
void
client_set_sticky(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->sticky != s)
    {
        c->sticky = s;
        banning_need_update((c)->screen);
        ewmh_client_update_hints(c);
        hook_property(c, "sticky");
        luaA_object_emit_signal(L, cidx, "property::sticky", 0);
    }
}

/** Set a client fullscreen, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client fullscreen.
 */
void
client_set_fullscreen(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    
#ifdef LAB126
    /* no support for these extended winmgr hints and they cause unwanted client restacks */
    return;
#endif

    if(c->fullscreen != s)
    {
        area_t geometry;

        /* become fullscreen! */
        if(s)
        {
            /* Make sure the current geometry is stored without titlebar. */
            titlebar_ban(c->titlebar);
            /* remove any max state */
            client_set_maximized_horizontal(L, cidx, false);
            client_set_maximized_vertical(L, cidx, false);
            /* You can only be part of one of the special layers. */
            client_set_below(L, cidx, false);
            client_set_above(L, cidx, false);
            client_set_ontop(L, cidx, false);
#ifdef LAB126
            client_set_hiddenLayer(L, cidx, false);
            client_set_dialogLayer(L, cidx, false);
            client_set_kbLayer(L, cidx, false);
            client_set_alertLayer(L, cidx, false);
#endif

            geometry = screen_area_get(c->screen, false);
            c->geometries.fullscreen = c->geometry;
            c->border_width_fs = c->border_width;
            client_set_border_width(L, cidx, 0);
            c->fullscreen = true;
        }
        else
        {
            geometry = c->geometries.fullscreen;
            c->fullscreen = false;
            client_set_border_width(L, cidx, c->border_width_fs);
        }
        
        client_resize(c, geometry, false);
        client_stack();
        ewmh_client_update_hints(c);
        hook_property(c, "fullscreen");
        luaA_object_emit_signal(L, cidx, "property::fullscreen", 0);
    }
}

/** Set a client horizontally maximized.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s The maximized status.
 */
void
client_set_maximized_horizontal(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    
#ifdef LAB126
    /* no support for these extended winmgr hints and they cause unwanted client restacks */
    return;
#endif    

    if(c->maximized_horizontal != s)
    {
        area_t geometry;

        if((c->maximized_horizontal = s))
        {
            /* remove fullscreen mode */
            client_set_fullscreen(L, cidx, false);

            geometry = screen_area_get(c->screen, true);
            geometry.y = c->geometry.y;
            geometry.height = c->geometry.height;
            c->geometries.max.x = c->geometry.x;
            c->geometries.max.width = c->geometry.width;
        }
        else
        {
            geometry = c->geometry;
            geometry.x = c->geometries.max.x;
            geometry.width = c->geometries.max.width;
        }
        
        client_resize(c, geometry, c->size_hints_honor);
        client_stack();
        ewmh_client_update_hints(c);
        hook_property(c, "maximized_horizontal");
        luaA_object_emit_signal(L, cidx, "property::maximized_horizontal", 0);
    }
}

/** Set a client vertically maximized.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s The maximized status.
 */
void
client_set_maximized_vertical(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    
#ifdef LAB126
    /* no support for these extended winmgr hints and they cause unwanted client restacks */
    return;
#endif      

    if(c->maximized_vertical != s)
    {
        area_t geometry;

        if((c->maximized_vertical = s))
        {
            /* remove fullscreen mode */
            client_set_fullscreen(L, cidx, false);

            geometry = screen_area_get(c->screen, true);
            geometry.x = c->geometry.x;
            geometry.width = c->geometry.width;
            c->geometries.max.y = c->geometry.y;
            c->geometries.max.height = c->geometry.height;
        }
        else
        {
            geometry = c->geometry;
            geometry.y = c->geometries.max.y;
            geometry.height = c->geometries.max.height;
        }
        
        client_resize(c, geometry, c->size_hints_honor);
        client_stack();
        ewmh_client_update_hints(c);
        hook_property(c, "maximized_vertical");
        luaA_object_emit_signal(L, cidx, "property::maximized_vertical", 0);
    }
}

/** Set a client above, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client above.
 */
void
client_set_above(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->above != s)
    {
        /* You can only be part of one of the special layers. */
        if(s)
        {
            client_set_below(L, cidx, false);
            client_set_ontop(L, cidx, false);
            client_set_fullscreen(L, cidx, false);
#ifdef LAB126
            client_set_hiddenLayer(L, cidx, false);
            client_set_dialogLayer(L, cidx, false);
            client_set_kbLayer(L, cidx, false);
            client_set_alertLayer(L, cidx, false);
#endif
        }
        c->above = s;
        client_stack();
        ewmh_client_update_hints(c);
        /* execute hook */
        hook_property(c, "above");
        luaA_object_emit_signal(L, cidx, "property::above", 0);
    }
}

/** Set a client below, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client below.
 */
void
client_set_below(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->below != s)
    {
        /* You can only be part of one of the special layers. */
        if(s)
        {
            client_set_above(L, cidx, false);
            client_set_ontop(L, cidx, false);
            client_set_fullscreen(L, cidx, false);
#ifdef LAB126
            client_set_hiddenLayer(L, cidx, false);
            client_set_dialogLayer(L, cidx, false);
            client_set_kbLayer(L, cidx, false);
            client_set_alertLayer(L, cidx, false);
#endif
        }
        c->below = s;
        client_stack();
        ewmh_client_update_hints(c);
        /* execute hook */
        hook_property(c, "below");
        luaA_object_emit_signal(L, cidx, "property::below", 0);
    }
}

#ifdef LAB126

/**
 * Sets the save under flag on a given client
 *
 * @param L The Lua VM state.
 * @param cidx The client index.
 * @param s new save under value
 */
void
client_set_save_under(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    c->save_under = s;
    xcb_change_window_attributes(globalconf.connection, c->window,
            XCB_CW_SAVE_UNDER, (const uint32_t []) { c->save_under });
}

/**
 * Sets the backing store flag for a given client
 *
 * @param L The Lua VM state.
 * @param cidx The client index.
 * @param s new backing store value
 */
void
client_set_backing_store(lua_State *L, int cidx, int s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if (s != XCB_BACKING_STORE_NOT_USEFUL &&
            s != XCB_BACKING_STORE_WHEN_MAPPED &&
            s != XCB_BACKING_STORE_ALWAYS) {
        return;
    }

    c->backing_store = s;
    xcb_change_window_attributes(globalconf.connection, c->window,
            XCB_CW_BACKING_STORE, (const uint32_t []) { c->backing_store });
}

/** Set a client to normal layer
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client above.
 */
void
client_set_normal(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    /*normal is not a true layer, but lack of being another layer
    setting normal to false does not really do anything */
    if(s)
    {
        /* clear any special layers. */
        if(s)
        {
            client_set_below(L, cidx, false);
            client_set_ontop(L, cidx, false);
            client_set_fullscreen(L, cidx, false);
            client_set_hiddenLayer(L, cidx, false);
            client_set_dialogLayer(L, cidx, false);
            client_set_kbLayer(L, cidx, false);
            client_set_alertLayer(L, cidx, false);
        }
        client_stack();
        ewmh_client_update_hints(c);
    }
}

/** Set a client hiddenLayer, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client below.
 */
void
client_set_hiddenLayer(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->hiddenLayer != s)
    {
        /* You can only be part of one of the special layers. */
        if(s)
        {
            client_set_above(L, cidx, false);
            client_set_below(L, cidx, false);
            client_set_ontop(L, cidx, false);
            client_set_fullscreen(L, cidx, false);
            client_set_dialogLayer(L, cidx, false);
            client_set_kbLayer(L, cidx, false);
            client_set_alertLayer(L, cidx, false);

        }

        c->hiddenLayer = s;
        client_stack();

        ewmh_client_update_hints(c);
        /* execute hook */
        hook_property(c, "hiddenLayer");
        luaA_object_emit_signal(L, cidx, "property::hiddenLayer", 0);
    }
}

/** Set a client dialogLayer, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client below.
 */
void
client_set_dialogLayer(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->dialogLayer != s)
    {
        /* You can only be part of one of the special layers. */
        if(s)
        {
            client_set_above(L, cidx, false);
            client_set_below(L, cidx, false);
            client_set_ontop(L, cidx, false);
            client_set_fullscreen(L, cidx, false);
            client_set_hiddenLayer(L, cidx, false);
            client_set_kbLayer(L, cidx, false);
            client_set_alertLayer(L, cidx, false);
        }
        c->dialogLayer = s;
        client_stack();
        ewmh_client_update_hints(c);
        /* execute hook */
        hook_property(c, "dialogLayer");
        luaA_object_emit_signal(L, cidx, "property::dialogLayer", 0);
    }
}

/** Set a client alertLayer, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client below.
 */
void
client_set_alertLayer(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->alertLayer != s)
    {
        /* You can only be part of one of the special layers. */
        if(s)
        {
            client_set_above(L, cidx, false);
            client_set_below(L, cidx, false);
            client_set_ontop(L, cidx, false);
            client_set_fullscreen(L, cidx, false);
            client_set_hiddenLayer(L, cidx, false);
            client_set_kbLayer(L, cidx, false);
            client_set_dialogLayer(L, cidx, false);
        }
        c->alertLayer = s;
        client_stack();
        ewmh_client_update_hints(c);
        /* execute hook */
        hook_property(c, "dialogLayer");
        luaA_object_emit_signal(L, cidx, "property::dialogLayer", 0);
    }
}

/** Set a client kbLayer, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client below.
 */
void
client_set_kbLayer(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->kbLayer != s)
    {
        /* You can only be part of one of the special layers. */
        if(s)
        {
            client_set_above(L, cidx, false);
            client_set_below(L, cidx, false);
            client_set_ontop(L, cidx, false);
            client_set_fullscreen(L, cidx, false);
            client_set_dialogLayer(L, cidx, false);
            client_set_hiddenLayer(L, cidx, false);
            client_set_alertLayer(L, cidx, false);
        }
        c->kbLayer = s;
        client_stack();
        ewmh_client_update_hints(c);
        /* execute hook */
        hook_property(c, "kbLayer");
        luaA_object_emit_signal(L, cidx, "property::kbLayer", 0);
    }
}
#endif

/** Set a client modal, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client modal attribute.
 */
void
client_set_modal(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->modal != s)
    {
        c->modal = s;
#ifndef LAB126
        client_stack();
#endif
        ewmh_client_update_hints(c);
        /* execute hook */
        hook_property(c, "modal");
        luaA_object_emit_signal(L, cidx, "property::modal", 0);
    }
}

/** Set a client ontop, or not.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client ontop attribute.
 */
void
client_set_ontop(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->ontop != s)
    {
        /* You can only be part of one of the special layers. */
        if(s)
        {
            client_set_above(L, cidx, false);
            client_set_below(L, cidx, false);
            client_set_fullscreen(L, cidx, false);
#ifdef LAB126
            client_set_hiddenLayer(L, cidx, false);
            client_set_dialogLayer(L, cidx, false);
            client_set_kbLayer(L, cidx, false);
            client_set_alertLayer(L, cidx, false);
#endif
        }
        c->ontop = s;
        client_stack();
        /* execute hook */
        hook_property(c, "ontop");
        luaA_object_emit_signal(L, cidx, "property::ontop", 0);
    }
}

/** Set a client skip taskbar attribute.
 * \param L Tha Lua VM state.
 * \param cidx The client index.
 * \param s Set or not the client skip taskbar attribute.
 */
void
client_set_skip_taskbar(lua_State *L, int cidx, bool s)
{
    client_t *c = luaA_client_checkudata(L, cidx);

    if(c->skip_taskbar != s)
    {
        c->skip_taskbar = s;
        ewmh_client_update_hints(c);
        luaA_object_emit_signal(L, cidx, "property::skip_taskbar", 0);
    }
}

/** Unban a client and move it back into the viewport.
 * \param c The client.
 */
void
client_unban(client_t *c)
{
    if(c->isbanned)
    {
        xcb_map_window(globalconf.connection, c->window);

        c->isbanned = false;
    }
}

/** Unmanage a client.
 * \param c The client.
 */
void
client_unmanage(client_t *c)
{

    tag_array_t *tags = &c->screen->tags;

    /* Reset transient_for attributes of widows that maybe referring to us */
    foreach(_tc, globalconf.clients)
    {
        client_t *tc = *_tc;
        if(tc->transient_for == c)
            tc->transient_for = NULL;
    }

    if(globalconf.screens.tab[c->phys_screen].prev_client_focus == c)
        globalconf.screens.tab[c->phys_screen].prev_client_focus = NULL;

    if(globalconf.screens.tab[c->phys_screen].client_focus == c)
        client_unfocus(c);

    /* remove client from global list and everywhere else */
    foreach(elem, globalconf.clients)
        if(*elem == c)
        {
            client_array_remove(&globalconf.clients, elem);
            break;
        }

    stack_client_remove(c);
    for(int i = 0; i < tags->len; i++)
        untag_client(c, tags->tab[i]);

    /* call hook */
    if(globalconf.hooks.unmanage != LUA_REFNIL)
    {
        luaA_object_push(globalconf.L, c);
        luaA_dofunction_from_registry(globalconf.L, globalconf.hooks.unmanage, 1, 0);
    }

    luaA_object_push(globalconf.L, c);
    luaA_class_emit_signal(globalconf.L, &client_class, "unmanage", 1);

    /* Call hook to notify list change */
    if(globalconf.hooks.clients != LUA_REFNIL)
        luaA_dofunction_from_registry(globalconf.L, globalconf.hooks.clients, 0, 0);

    luaA_class_emit_signal(globalconf.L, &client_class, "list", 0);

    if(strut_has_value(&c->strut))
        screen_emit_signal(globalconf.L, c->screen, "property::workarea", 0);

    window_state_set(c->window, XCB_WM_STATE_WITHDRAWN);

    titlebar_client_detach(c);

    ewmh_update_net_client_list(c->phys_screen);

#ifdef LAB126
    xcb_damage_destroy(globalconf.connection, c->damage);
#endif

    /* set client as invalid */
    c->invalid = true;

    luaA_object_unref(globalconf.L, c);
}

/** Kill a client via a WM_DELETE_WINDOW request or KillClient if not
 * supported.
 * \param c The client to kill.
 */
void
client_kill(client_t *c)
{
    if(client_hasproto(c, WM_DELETE_WINDOW))
    {
        xcb_client_message_event_t ev;

        /* Initialize all of event's fields first */
        p_clear(&ev, 1);

        ev.response_type = XCB_CLIENT_MESSAGE;
        ev.window = c->window;
        ev.format = 32;
        ev.data.data32[1] = XCB_CURRENT_TIME;
        ev.type = WM_PROTOCOLS;
        ev.data.data32[0] = WM_DELETE_WINDOW;

        xcb_send_event(globalconf.connection, false, c->window,
                       XCB_EVENT_MASK_NO_EVENT, (char *) &ev);
    }
    else
        xcb_kill_client(globalconf.connection, c->window);
}

/** Get all clients into a table.
 * \param L The Lua VM state.
 * \return The number of elements pushed on stack.
 * \luastack
 * \lparam An optional screen number.
 * \lreturn A table with all clients.
 */
static int
luaA_client_get(lua_State *L)
{
    int i = 1, screen;

    screen = luaL_optnumber(L, 1, 0) - 1;

    lua_newtable(L);

    if(screen == -1)
        foreach(c, globalconf.clients)
        {
            luaA_object_push(L, *c);
            lua_rawseti(L, -2, i++);
        }
    else
    {
        luaA_checkscreen(screen);
        foreach(c, globalconf.clients)
            if((*c)->screen == &globalconf.screens.tab[screen])
            {
                luaA_object_push(L, *c);
                lua_rawseti(L, -2, i++);
            }
    }

    return 1;
}

/** Check if a client is visible on its screen.
 * \param L The Lua VM state.
 * \return The number of elements pushed on stack.
 * \luastack
 * \lvalue A client.
 * \lreturn A boolean value, true if the client is visible, false otherwise.
 */
static int
luaA_client_isvisible(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);
    lua_pushboolean(L, client_isvisible(c, c->screen));
    return 1;
}

/** Set client border width.
 * \param L The Lua VM state.
 * \param cidx The client index.
 * \param width The border width.
 */
void
client_set_border_width(lua_State *L, int cidx, int width)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    uint32_t w = width;

    if(width > 0 && (c->type == WINDOW_TYPE_DOCK
                     || c->type == WINDOW_TYPE_SPLASH
                     || c->type == WINDOW_TYPE_DESKTOP
                     || c->fullscreen))
        return;

    if(width == c->border_width || width < 0)
        return;

    /* disallow change of border width if the client is fullscreen */
    if(c->fullscreen)
        return;

    /* Update geometry with the new border. */
    c->geometry.width -= 2 * c->border_width;
    c->geometry.height -= 2 * c->border_width;

    c->border_width = width;
    xcb_configure_window(globalconf.connection, c->window,
                         XCB_CONFIG_WINDOW_BORDER_WIDTH, &w);

    c->geometry.width += 2 * c->border_width;
    c->geometry.height += 2 * c->border_width;

    /* Changing border size also affects the size of the titlebar. */
    titlebar_update_geometry(c);

    hook_property(c, "border_width");
    luaA_object_emit_signal(L, cidx, "property::border_width", 0);
}

/** Set a client icon.
 * \param L The Lua VM state.
 * \param cidx The client index on the stack.
 * \param iidx The image index on the stack.
 */
void
client_set_icon(lua_State *L, int cidx, int iidx)
{
    client_t *c = luaA_client_checkudata(L, cidx);
    /* convert index to absolute */
    cidx = luaA_absindex(L, cidx);
    iidx = luaA_absindex(L, iidx);
    luaA_checkudata(L, iidx, &image_class);
    luaA_object_unref_item(L, cidx, c->icon);
    c->icon = luaA_object_ref_item(L, cidx, iidx);
    luaA_object_emit_signal(L, cidx < iidx ? cidx : cidx - 1, "property::icon", 0);
    /* execute hook */
    hook_property(c, "icon");
}

/** Kill a client.
 * \param L The Lua VM state.
 *
 * \luastack
 * \lvalue A client.
 */
static int
luaA_client_kill(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);
    client_kill(c);
    return 0;
}

/** Swap a client with another one.
 * \param L The Lua VM state.
 * \luastack
 * \lvalue A client.
 * \lparam A client to swap with.
 */
static int
luaA_client_swap(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);
    client_t *swap = luaA_client_checkudata(L, 2);

    if(c != swap)
    {
        client_t **ref_c = NULL, **ref_swap = NULL;
        foreach(item, globalconf.clients)
        {
            if(*item == c)
                ref_c = item;
            else if(*item == swap)
                ref_swap = item;
            if(ref_c && ref_swap)
                break;
        }
        /* swap ! */
        *ref_c = swap;
        *ref_swap = c;

        /* Call hook to notify list change */
        if(globalconf.hooks.clients != LUA_REFNIL)
            luaA_dofunction_from_registry(L, globalconf.hooks.clients, 0, 0);

        luaA_class_emit_signal(globalconf.L, &client_class, "list", 0);
    }

    return 0;
}

/** Access or set the client tags.
 * \param L The Lua VM state.
 * \return The number of elements pushed on stack.
 * \lparam A table with tags to set, or none to get the current tags table.
 * \return The clients tag.
 */
static int
luaA_client_tags(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);
    tag_array_t *tags = &c->screen->tags;
    int j = 0;

    if(lua_gettop(L) == 2)
    {
        luaA_checktable(L, 2);
        for(int i = 0; i < tags->len; i++)
            untag_client(c, tags->tab[i]);
        lua_pushnil(L);
        while(lua_next(L, 2))
            tag_client(c);
        lua_pop(L, 1);
    }

    lua_newtable(L);
    foreach(tag, *tags)
        if(is_client_tagged(c, *tag))
        {
            luaA_object_push(L, *tag);
            lua_rawseti(L, -2, ++j);
        }

    return 1;
}

/** Raise a client on top of others which are on the same layer.
 * \param L The Lua VM state.
 * \luastack
 * \lvalue A client.
 */
static int
luaA_client_raise(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);
    client_raise(c);
    return 0;
}

/** Lower a client on bottom of others which are on the same layer.
 * \param L The Lua VM state.
 * \luastack
 * \lvalue A client.
 */
static int
luaA_client_lower(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);

    stack_client_push(c);

    /* Traverse all transient layers. */
    for(client_t *tc = c->transient_for; tc; tc = tc->transient_for)
        stack_client_push(tc);

    client_stack();

    return 0;
}

/** Redraw a client by unmapping and mapping it quickly.
 * \param L The Lua VM state.
 *
 * \luastack
 * \lvalue A client.
 */
static int
luaA_client_redraw(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);

    xcb_unmap_window(globalconf.connection, c->window);
    xcb_map_window(globalconf.connection, c->window);

    /* Set the focus on the current window if the redraw has been
       performed on the window where the pointer is currently on
       because after the unmapping/mapping, the focus is lost */
    if(globalconf.screen_focus->client_focus == c)
    {
        client_unfocus(c);
        client_focus(c);
    }

    return 0;
}

/** Stop managing a client.
 * \param L The Lua VM state.
 * \return The number of elements pushed on stack.
 * \luastack
 * \lvalue A client.
 */
static int
luaA_client_unmanage(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);
    client_unmanage(c);
    return 0;
}


#ifdef LAB126
/** Destroy a window.
 * \param L The Lua VM state.
 * \luastack
 * \lvalue A client.
 */
static int
luaA_client_destroy(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);
    if (client_hasproto(c, WM_DELETE_WINDOW))
    {
        client_kill(c);
    }
    else
    {
        xcb_destroy_window(globalconf.connection, c->window);
    }
    return 0;
}

/**
 * attempt to layer hidden windows underneath blank background window
 * @params c client to stack underneath
 * @return true (1) is stacked, otherwise false (0)
 */
static int
client_stack_under_background_window(client_t * c){

    LOGDBG("stack under background");

    /*initialize falsy*/
    int returnVal = 0;

    /* loop looking for blank background client*/
    reverse_foreach(node, globalconf.stack){
        client_t* checkClient = *node;
        int checkClientLayer = client_layer_translator(checkClient);

        /* validate correct layer and is valid */
        if (checkClientLayer == (LAYER_HIDDEN + 1) && validate_client_window(checkClient)){
            LOGDBG("found blank background window at %p :: %s :: %d\n", checkClient->window, checkClient->alt_name, checkClientLayer);

            client_stack_below(c, checkClient->window);

            /* return true if stacked under background */
            returnVal = 1;
            break;
        }
    }

    return returnVal;
}

/**
 * stacks client to new layer immediately and
 * without full restack operation
 * @params c client
 * @params newLayer layer to stack to
 */
static int
client_set_layer_without_restack(client_t * c, int newLayer){
    LOGDBG("luaA_client_set_layer_without_restack %p, %s %d", c->window, c->alt_name ,newLayer);

    /* validate layer is not above layercount */
    if (newLayer >= LAYER_COUNT){
        /* invalid layer */
        return 0;
    }

    if (newLayer == (int) client_layer_translator(c)){
        /* client is already on correct layer */
        LOGDBG("layer already correct");
        return 0;
    }

    /* move to top of awesomes client stack to ensure */
    /* relative position in layer on any given */
    /* future restack operations */
    if (!c->invalid){
        client_raise_no_restack(c);
    }

    /*
     * if globalconf.client_need_stack_refresh is set
     * we already failed and are going to do a full restack
     * on the next run through the event loop
     */
    if (!globalconf.client_need_stack_refresh){

        if (newLayer == LAYER_BELOW){
            /* when blank background window comes in, trigger a full restack */
            /* this helps with certain timing edge conditions on boot */
            LOGDBG("luaA_client_set_layer_without_restack, full restack layering blank background");
            client_stack();
        } else if (newLayer != LAYER_HIDDEN || !client_stack_under_background_window(c)){
            /* find client to be above */
            /* in x stack by doing a reverse search */
            /* through stack and find best match */
            client_t * belowMe = NULL;
            int matchedLayer = -1;

            reverse_foreach(node, globalconf.stack){
                client_t* checkClient = *node;
                int checkClientLayer = client_layer_translator(checkClient);
                LOGDBG("look at %p :: %s :: %d\n", checkClient->window, checkClient->alt_name, checkClientLayer);
                if((checkClientLayer > matchedLayer) &&
                        (checkClientLayer <= newLayer) &&
                        (checkClient != c) &&
                        (!checkClient->invalid) &&
                        (checkClient->transient_for != c) ){
                    LOGDBG ("belowMe found %p :: %s", checkClient->window, checkClient->alt_name);

                    /* validate window is usable */
                    if (validate_client_window(checkClient)){
                        belowMe = checkClient;
                        matchedLayer = checkClientLayer;
                    }
                }
            }

            if (belowMe != NULL){
                /** when stacking a normal client stacks above a client */
                /** with transient children, stack above top most */
                /** transient child */
                if (belowMe->has_transient_child && c->transient_for != belowMe){
                    reverse_foreach(node, globalconf.stack){
                        if( ((*node)->transient_for) &&
                                ((*node)->transient_for == belowMe) &&
                                (validate_client_window(*node))){
                            belowMe = *node;
                            LOGINFO("adjusting below me to top transient window");
                        }
                    }
                }

                /* found client we need to be "above" */
                client_stack_above(c,  belowMe->window);

                /* re-validate after we layer against the window to catch any timing issues */
                if (!validate_client_window(belowMe)){
                    LOGINFO("afterwards belowMe window was bad, force full restack");
                    /* full restack on fail case*/
                    client_stack();
                }

            } else {
                /* no belowme window, stack to the bottom */
                client_stack_below(c, XCB_NONE);
            }
        }

    }

    /* clear any layer flags */
    c->hiddenLayer = false;
    c->below = false;
    c->dialogLayer = false;
    c->kbLayer = false;
    c->alertLayer = false;
    c->above = false;
    c->fullscreen = false;
    c->ontop = false;

    /* not omitting signal */
    /* set correct layer flag */
    switch(newLayer){
    case LAYER_HIDDEN:
        c->hiddenLayer = true;
        break;
    case LAYER_BELOW:
        c->below = true;
        break;
    case LAYER_DIALOG:
        c->dialogLayer = true;
        break;
    case LAYER_KB:
        c->kbLayer = true;
        break;
    case LAYER_ALERT:
        c->alertLayer = true;
        break;
    case LAYER_ABOVE:
        c->above = true;
        break;
    case LAYER_FULLSCREEN:
        c->fullscreen = true;
        break;
    case LAYER_ONTOP:
        c->ontop = true;
        break;
    default:
        /* normal layer, nothing gets set */
        break;
    }

    ewmh_client_update_hints(c);

    xcb_flush(globalconf.connection);

    LOGDBG("done luaA_client_set_layer_without_restack");

    return 0;
}

/**
 * LUA entry point to relayer a client without
 * forcing a full restack of all clients
 */
static int
luaA_client_set_layer_without_restack(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);
    int newLayer = luaL_checknumber(L, 2);

    return client_set_layer_without_restack(c, newLayer);
}

/**
 * validates the X Stacking order matches what we expect
 * given awesome's window layering and internal stack
 */
static bool
client_validate_stacking_order(void){
    LOGTIMESTAMP("client_validate_stacking_order start");

    /* s is not to be freed, see comment on xutil_screen_get */
    xcb_screen_t *s = xutil_screen_get(globalconf.connection, 0);

    /** Get X child tree from root */
    xcb_query_tree_cookie_t treeCookie = xcb_query_tree (globalconf.connection, s->root);

    xcb_query_tree_reply_t *tree;
    xcb_generic_error_t *err;

    tree = xcb_query_tree_reply (globalconf.connection, treeCookie, &err);
    if (!tree) {
        LOGINFO("failed to get tree info");
        return false;
    }

    unsigned int num_children = xcb_query_tree_children_length (tree);

    if (num_children <= 0){
        free (tree);
        /** children in X stack, clients may be invalid, but not out of order */
        return true;
    }

    /** get list of children windows */
    /** memory for child list freed along with tree */
    xcb_window_t *child_list = xcb_query_tree_children (tree);
    int xPosition = 0;

    layer_t layer;
    bool passed = true;

    /** loop through our stack in order validating against X stack */
    for(layer = LAYER_HIDDEN; layer < LAYER_COUNT; layer++){
        LOGDBG("+++++checking client layer %d\n", layer);
        foreach(node, globalconf.stack){
            /*
             * set found to negative value for found below
             * expected, positive for above (the latter is correct)
             */
            int found = 0;
            client_t* c = *node;
            if(client_layer_translator(c) == layer){
                /* walk forward xPosition looking for this client */
                for (int i = xPosition; i < (int)num_children; i++){
                    LOGDBG("window %p", child_list[i]);
                    if (child_list[i] == c->window){
                        /* found above */
                        found = 1;
                        /* xPosition moves to next client */
                        xPosition = i+1<(int)num_children?i+1:i;
                        break;
                    }
                }

                /*
                * if we did not find it above our current
                * xPosition, look below. The reason to further validate
                * if the window is below because there are cases where
                * the window is gone but because awesome is on an event loop
                * the unmanage may still be pending
                */
                if (found != 1 && xPosition > 0){
                    LOGDBG("window not found above, look below");
                    /* walk forward xPosition looking for this client */
                    for (int i = 0; i < xPosition; i++){
                        LOGDBG("window %p", child_list[i]);
                        if (child_list[i] == c->window){
                            /* found below */
                            found = -1;
                            break;
                        }
                    }
                }

                /*
                * if found below the stacking order in awesome
                * is incorrect
                */
                if (found < 0){
                    passed = false;
                    break;
                }
            }
        }
        LOGDBG("-----checking client layer %d\n", layer);
    }

    if (!passed){
        LOGINFO("client stack is off from x stacking order");
    } else {
        LOGDBG("client stack matches X stacking order");
    }

    /** memory for child_list freed here as well */
    free (tree);

    LOGTIMESTAMP("client_validate_stacking_order end");

    return passed;
}

/**
 * LUA entry point to check z ordering in x stack against awesome's stack
 */
static int
luaA_validate_client_validate_stacking_order(lua_State *L){
    if (!client_validate_stacking_order()){
        /* force a full restack to correct stacking orer */
        client_stack();
    }

    return 0;
}

/**
 *LUA logging only call to check z ordering
 */
static int
luaA_log_all_clients(lua_State *L)
{
    LOGINFO("+++++in stack");
    foreach(node, globalconf.stack){
        client_t* checkClient = *node;
        LOGINFO("client %p :: %s on layer %d invalid %d\n", checkClient->window, checkClient->alt_name,
                client_layer_translator(checkClient), checkClient->invalid);
    }
    LOGINFO("-----in stack");

    LOGINFO("+++++in client");
    foreach(node, globalconf.clients){
        client_t* checkClient = *node;
        LOGINFO("client %p :: %s on layer %d invalid %d\n", checkClient->window, checkClient->alt_name,
                client_layer_translator(checkClient), checkClient->invalid);
    }
    LOGINFO("-----in clients");

    xcb_screen_t *s = xutil_screen_get(globalconf.connection, 0);
    xcb_query_tree_cookie_t treeCookie = xcb_query_tree (globalconf.connection, s->root);

    xcb_query_tree_reply_t *tree;
    xcb_generic_error_t *err;

    tree = xcb_query_tree_reply (globalconf.connection, treeCookie, &err);
    if (!tree) {
        LOGINFO("failed  get tree info");
        return 0;
    }

    unsigned int num_children = xcb_query_tree_children_length (tree);

    if (num_children > 0){
        xcb_window_t *child_list = xcb_query_tree_children (tree);
        int i;
        LOGINFO("+++++ in X real stack");
        for (i = 0; i < (int)num_children; i++){
            LOGINFO("window %p", child_list[i]);
        }
        LOGINFO("----- in X real stack");
    } else {
        LOGINFO("no children in x stack");
    }

    free (tree);

    return 0;
}

/**
 * LUA entry point to force a full restack of all client windows
 */
static int
luaA_force_restack(lua_State *L){
    client_stack();

    return 0;
}
#define LEFT(geom) (geom->x)
#define TOP(geom) (geom->y)
#define RIGHT(geom) (geom->x+geom->width-1)
#define BOTTOM(geom) (geom->y+geom->height-1)
/**
 * util to check whether rectangles overlap
 */
static bool
geometry_intersect(area_t* r1, area_t* r2)
{

    /* empty rects cannot intersect */
    if (!r1->width || !r1->height || !r2->width || !r2->height){
        return false;
    }

    /* return negate of not intersect */
    return ! ( LEFT(r2) > RIGHT(r1)
        || RIGHT(r2) < LEFT(r1)
        || TOP(r2) > BOTTOM(r1)
        || BOTTOM(r2) < TOP(r1)
        );
}

/**
 * Get the client at the (x,y) position
 */
static int
luaA_get_client_at(lua_State *L)
{
    int x = luaL_checknumber(L, 1);
    int y = luaL_checknumber(L, 2);
    client_t* found = NULL;

    /* run through clients in reverse order looking for client*/
    reverse_foreach(node, globalconf.stack){
        client_t* c2 = *node;
        
        if ((!c2->hiddenLayer) &&
            ((x >= c2->geometry.x) && (x <= c2->geometry.x + c2->geometry.width)) &&
            ((y >= c2->geometry.y) && (y <= c2->geometry.y + c2->geometry.height))) {

            if (!found){
                LOGDBG("found client at x,y position. client = %p :: %s ", c2->window, c2->alt_name);
                found = c2;
            } else {
                layer_t layerFound = (found->transient_for) ? client_layer_translator(found->transient_for) : client_layer_translator(found);
                layer_t layerC2    = (c2->transient_for) ? client_layer_translator(c2->transient_for) : client_layer_translator(c2);

                if (layerC2 > layerFound) {
                    LOGDBG("replacing the client. new client = %p :: %s ", c2->window, c2->alt_name);
                    found = c2;
                }
            }
        }
    }
    luaA_object_push(globalconf.L, found);
    return 1;
}

/**
 * Get the client by windowId
 */
static int
luaA_get_client_by_windowId(lua_State *L)
{
    int windowId = luaL_checknumber(L, 1);
    client_t* c = NULL;

    /* run through clients in reverse order looking for client*/
    reverse_foreach(node, globalconf.stack){
        if ( ((client_t*)*node)->window == windowId) {
            c = *node;
            break;
        }
    }
    luaA_object_push(globalconf.L, c);
    return 1;
}

/**
 * check to see if client is obscure. In other words is there a client "above"
 * this client with an overlapping rectangle
 */
static int
luaA_client_is_obscured(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);
    int clientLayer = client_layer_translator(c);
    bool obscured = false;
    bool loopedPastC = false;

    /* run through clients in reverse order looking for overlapping clients */
    reverse_foreach(node, globalconf.stack){
        client_t* c2 = *node;
        int compareLayer = client_layer_translator(c2);
        LOGDBG("look at %p :: %s :: %d", c2->window, c2->alt_name, compareLayer);

        if (c2 == c){
            /* any client past c in client list */
            /* on the same layer is "below" this client */
            loopedPastC = true;
            continue;
        }

        /* check to see if above our client */
        if(((compareLayer > clientLayer) || ((compareLayer == clientLayer) && !loopedPastC ) ) &&
                (!c2->invalid) &&
                (c2->transient_for != c) ){
            LOGDBG ("aboveme found %p :: %s\n", c2->window, c2->alt_name);

            /* look for geometry overlap */
            obscured = geometry_intersect(&(c->geometry), &(c2->geometry));
            if (obscured){
                LOGDBG("window is obscured");
                break;
            }
        }
    }

    lua_pushboolean(L, obscured);
    return 1;
}


/**
 * Compares the relative stack order of two clients
 * assuming they are on the same layer. Returns true
 * if c is above c2.
 */
static bool
matching_layer_clients_is_above(client_t* c, client_t *c2){
    int i = 0;
    int posC = -1;
    int posC2 = -1;
    foreach(node, globalconf.stack){
        /* which do we find first */
        if (*node == c) {
            posC = i;
        } else if (*node == c2) {
            posC2 = i;
        }

        i++;
    }

    /* in the off chance posC or posC2 is not found */
    /* and remain -1, behavior is good */
    /* if posC is not found, then the main client is not stacked */
    /* and thus can not be above anything */
    /*     posC = -1 and posC2 = -1 or value then false */
    /* if posC is found but not posC2, then true */
    /*     posC has value but posC2 is -1 then true */
    /* otherwise its a normal compare */
    if (posC > posC2){
        return true;
    }

    return false;
}

/**
 * check to see if client is above passed in client
 * NOTE the call returns if c is above c2 according to awesome's
 * stacking order, which may or may not sync directly at a given moment
 * to XLIB's stacking order as there is some async interaction between the
 * two
 */
static bool
client_is_above(client_t *c, client_t *c2)
{
    if (!c || !c2){
        return false;
    }
    /*
     * NOTE the code does make the assumption that we do not have
     * transient chains. In other words, we do not have window c transient_for
     * window b which is in turn transient for window a. This is a limit in a number of
     * places in the current code.
     */

    /* not above oneself */
    if (c == c2) {
        return false;
    }


    /* transient windows come back from  */
    /* client_layer_translator on the ignore layer */
    /* their position is relative to their parent window */
    if (c->transient_for){
        if (c->transient_for == c2){
            /* always above window we are transient for */
            return true;
        } else if (c2->transient_for == c->transient_for) {
            /* windows are both transient for the same window */
            /* order in awesome's client list is correct */
            /* so matching layer route is good enough */
            return matching_layer_clients_is_above(c, c2);
        } else {
            /* use parent */
            c = c->transient_for;
        }
    }

    int clientLayer = client_layer_translator(c);

    if (c2->transient_for){
        if (c2->transient_for == c){
            /* always above window we are transient for */
            return false;
        } else {
            /* use parent */
            c2 = c2->transient_for;
        }
    }

    int layerC2 = client_layer_translator(c2);


    bool isAbove = false;
    if (clientLayer == layerC2){
        /* on same layer, walk client array */
        /* run through clients in reverse order looking for overlapping clients */
        isAbove = matching_layer_clients_is_above(c, c2);

    } else if (clientLayer > layerC2){
        /* on above layer */
        isAbove = true;
    } /* else below, leave false */

    return isAbove;
}

/**
 * check to see if client is above passed in client
 * NOTE the call returns if c is above c2 according to awesome's
 * stacking order, which may or may not sync directly at a given moment
 * to XLIB's stacking order as there is some async interaction between the
 * two
 */
static int
luaA_client_is_above(lua_State *L)
{
    /* clint we are checking */
    client_t *c = luaA_client_checkudata(L, 1);

    /* client we are comparing to */
    client_t *c2 = luaA_client_checkudata(L, 2);

    lua_pushboolean(L, client_is_above(c, c2));
    return 1;
}



/**
 * check to see if client is above and partially covered by passed in client
 * NOTE the call returns if c is above c2 according to awesome's
 * stacking order, which may or may not sync directly at a given moment
 * to XLIB's stacking order as there is some async interaction between the
 * two
 */
static int
luaA_client_is_obscured_by(lua_State *L)
{
    /* clint we are checking */
    client_t *c = luaA_client_checkudata(L, 1);

    /* client we are comparing to */
    client_t *c2 = luaA_client_checkudata(L, 2);

    if(!c || !c2){
        lua_pushboolean(L, false);
    } else {
        lua_pushboolean(L, client_is_above(c2, c) && geometry_intersect(&(c->geometry), &(c2->geometry)));
    }

    return 1;
}

#endif

/**
 * Send the key events
 */
static int
luaA_client_sendButtonEvent(lua_State *L)
{
    xcb_button_press_event_t event;
    memset(&event, 0, sizeof(xcb_button_press_event_t));

    /* parse parameters */
    client_t *c = luaA_client_checkudata(L, 1);
    int buttonNumber = luaL_checknumber(L, 2);
    int x = luaL_checknumber(L, 3);
    int y = luaL_checknumber(L, 4);
    int isPress = luaL_checknumber(L, 5);

    event.response_type = isPress? XCB_BUTTON_PRESS : XCB_BUTTON_RELEASE;
    event.detail = buttonNumber;
    event.time = XCB_CURRENT_TIME;
    event.event = c->window;
    event.root = xutil_screen_get(globalconf.connection, c->phys_screen)->root;
    event.same_screen = 1;
    
    event.root_x = x;
    event.root_y = y;
    event.event_x = x - c->geometry.x;
    event.event_y = y - c->geometry.y;

    
    xcb_warp_pointer(globalconf.connection, XCB_NONE, c->window, 0, 0, 0, 0, event.event_x, event.event_y);
    xcb_flush(globalconf.connection);

    /* send the event */
    int mask = isPress?XCB_EVENT_MASK_BUTTON_PRESS:XCB_EVENT_MASK_BUTTON_RELEASE;
    xcb_send_event (globalconf.connection, false, c->window, /*event.response_type*/mask, (char *) &event);
    xcb_flush(globalconf.connection);

    
    LOGDBG("+++++ event_handle_button %d, %d, %d, %d %d",
            event.detail, event.state, event.response_type, event.time, event.sequence);
    
    return 0;
}


/**
 * Send the key events
 */
static int
luaA_client_sendKeyEvent(lua_State *L)
{
    xcb_key_press_event_t event;

    /* parse parameters */
    client_t *c = luaA_client_checkudata(L, 1);
    int keyType = luaL_checknumber(L, 2);
    int keycode = luaL_checknumber(L, 3);
    int state = luaL_checknumber(L, 4);

    /* construct the event */
    event.response_type = keyType;
    event.detail = keycode;
    event.time = XCB_CURRENT_TIME;
    event.event = c->window;
    event.state = state;

    /* send the event */
    int keyMask = keyType == XCB_KEY_PRESS?XCB_EVENT_MASK_KEY_PRESS:XCB_EVENT_MASK_KEY_RELEASE;
    xcb_send_event(globalconf.connection, true, c->window, keyMask, (char *) &event);
    xcb_flush(globalconf.connection);
    LOGDBG("key event sent keyType=%d keyCode=%d", keyType, keycode);
    
    return 0;
}

/** Return client geometry.
 * \param L The Lua VM state.
 * \return The number of elements pushed on stack.
 * \luastack
 * \lparam A table with new coordinates, or none.
 * \lreturn A table with client coordinates.
 */
static int
luaA_client_geometry(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);

    if(lua_gettop(L) == 2 && !lua_isnil(L, 2))
    {
        area_t geometry;

        luaA_checktable(L, 2);
        geometry.x = luaA_getopt_number(L, 2, "x", c->geometry.x);
        geometry.y = luaA_getopt_number(L, 2, "y", c->geometry.y);
        if(client_isfixed(c))
        {
            geometry.width = c->geometry.width;
            geometry.height = c->geometry.height;
        }
        else
        {
            geometry.width = luaA_getopt_number(L, 2, "width", c->geometry.width);
            geometry.height = luaA_getopt_number(L, 2, "height", c->geometry.height);
        }

        client_resize(c, geometry, c->size_hints_honor);
    }

    return luaA_pusharea(L, c->geometry);
}

/** Return client struts (reserved space at the edge of the screen).
 * \param L The Lua VM state.
 * \return The number of elements pushed on stack.
 * \luastack
 * \lparam A table with new strut values, or none.
 * \lreturn A table with strut values.
 */
static int
luaA_client_struts(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);

    if(lua_gettop(L) == 2)
    {
        luaA_tostrut(L, 2, &c->strut);
        ewmh_update_strut(c->window, &c->strut);
        hook_property(c, "struts");
        luaA_object_emit_signal(L, 1, "property::struts", 0);
        screen_emit_signal(L, c->screen, "property::workarea", 0);
    }

    return luaA_pushstrut(L, c->strut);
}

static int
luaA_client_set_screen(lua_State *L, client_t *c)
{
    if(globalconf.xinerama_is_active)
    {
        int screen = luaL_checknumber(L, -1) - 1;
        luaA_checkscreen(screen);
        screen_client_moveto(c, &globalconf.screens.tab[screen], true);
    }
    return 0;
}

static int
luaA_client_set_hidden(lua_State *L, client_t *c)
{
    bool b = luaA_checkboolean(L, -1);
    if(b != c->hidden)
    {
        c->hidden = b;
        banning_need_update((c)->screen);
        hook_property(c, "hidden");
        if(strut_has_value(&c->strut))
            screen_emit_signal(globalconf.L, c->screen, "property::workarea", 0);
        luaA_object_emit_signal(L, -3, "property::hidden", 0);
    }
    return 0;
}

static int
luaA_client_set_minimized(lua_State *L, client_t *c)
{
    client_set_minimized(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_fullscreen(lua_State *L, client_t *c)
{
    client_set_fullscreen(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_modal(lua_State *L, client_t *c)
{
    client_set_modal(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_maximized_horizontal(lua_State *L, client_t *c)
{
    client_set_maximized_horizontal(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_maximized_vertical(lua_State *L, client_t *c)
{
    client_set_maximized_vertical(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_icon(lua_State *L, client_t *c)
{
    client_set_icon(L, -3, -1);
    return 0;
}

static int
luaA_client_set_opacity(lua_State *L, client_t *c)
{
    if(lua_isnil(L, -1))
        client_set_opacity(L, -3, -1);
    else
        client_set_opacity(L, -3, luaL_checknumber(L, -1));
    return 0;
}

static int
luaA_client_set_sticky(lua_State *L, client_t *c)
{
    client_set_sticky(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_size_hints_honor(lua_State *L, client_t *c)
{
    c->size_hints_honor = luaA_checkboolean(L, -1);
    hook_property(c, "size_hints_honor");
    luaA_object_emit_signal(L, -3, "property::size_hints_honor", 0);
    return 0;
}

static int
luaA_client_set_border_width(lua_State *L, client_t *c)
{
    client_set_border_width(L, -3, luaL_checknumber(L, -1));
    return 0;
}

#ifdef LAB126

/**
 * Create and attach a shared memory segment.
 * \param size Memory size in bytes
 * \param info Segment info, will be filled in on return.
 * \return Pointer to allocated memory. NULL if failed.
 */
static void*
shm_attach(size_t size, xcb_shm_segment_info_t* info)
{
    if (info == NULL) {
        return NULL;
    }

    info->shmid = -1;
    info->shmseg = XCB_NONE;
    info->shmaddr = NULL;

    int id = shmget(IPC_PRIVATE, size, IPC_CREAT | 0700);
    if (id == -1)
    {
        return NULL;
    }

    /* Attach the segment to our process */
    void* shm = shmat (id, NULL, 0 /* read/write */);
    if (shm == (void*)-1)
    {
        shmctl(id, IPC_RMID, 0);
        return NULL;
    }

    /* Attach the segment to X */
    xcb_shm_seg_t segment = xcb_generate_id(globalconf.connection);
    xcb_void_cookie_t ck = xcb_shm_attach_checked(globalconf.connection, segment, id, 1);
    shmctl(id, IPC_RMID, 0);

    if (xcb_request_check(globalconf.connection, ck))
    {
        shmdt(shm);
        return NULL;
    }

    info->shmid = id;
    info->shmseg = segment;
    info->shmaddr = shm;

    return shm;
}

/**
 * Detach shared memory segment.
 * \param Segment info
 */
static void
shm_detach(xcb_shm_segment_info_t* info)
{
    if (info->shmseg != XCB_NONE) {
        xcb_shm_detach(globalconf.connection, info->shmseg);
    }
    if (info->shmaddr != NULL) {
        shmdt(info->shmaddr);
    }
}

/**
 * Draw rounded rectangle. Works correctly on A8 surfaces only.
 * \param surface Cairo surface
 * \param radius Corner radius
 * \param border_width Border width
 * \param color Rectangle color
 * \param back_color Background color
 * \param aa Need antialiasing or not
 */
static void
draw_rounded_rect(cairo_surface_t* surface,
        int radiusTopLeft, int radiusTopRight,
        int radiusBottomLeft, int radiusBottomRight,
        int border_width, uint8_t color, uint8_t back_color, bool aa)
{
    double w = cairo_image_surface_get_width(surface);
    double h = cairo_image_surface_get_height(surface);

    cairo_t* cr = cairo_create(surface);

    cairo_set_source_rgba (cr, 1.0, 1.0, 1.0, back_color / 255.0);
    cairo_set_operator (cr, CAIRO_OPERATOR_SOURCE);
    cairo_paint (cr);

    double x = border_width / 2.0;
    double y = border_width / 2.0;
    w -= border_width;
    h -= border_width;

    cairo_set_source_rgba (cr, 0.0, 0.0, 0.0, color / 255.0);
    cairo_set_line_width (cr, border_width);
    cairo_set_operator (cr, CAIRO_OPERATOR_SOURCE);
    if (!aa) {
        cairo_set_antialias(cr, CAIRO_ANTIALIAS_NONE);
    }

    /* topRight corner */
    if (radiusTopRight > 0){
        cairo_arc (cr, x + w - radiusTopRight, y + radiusTopRight, radiusTopRight, -M_PI / 2.0, 0);
    } else {
        cairo_move_to(cr, x + w, y);
    }

    /* right side */
    cairo_line_to(cr, x + w, y + h - radiusBottomRight);
    cairo_stroke (cr);

    /* bottomRight corner */
    if (radiusBottomRight > 0){
        cairo_arc (cr, x + w - radiusBottomRight, y + h - radiusBottomRight, radiusBottomRight, 0, M_PI / 2.0);
    } else {
        cairo_move_to(cr, x + w, y + h);
    }

    /* bottom side */
    cairo_line_to(cr, x + radiusBottomLeft, y + h);
    cairo_stroke (cr);

    /* bottomLeft corner */
    if (radiusBottomLeft > 0){
        cairo_arc (cr, x + radiusBottomLeft, y + h - radiusBottomLeft, radiusBottomLeft, M_PI / 2.0, M_PI);
    } else {
        cairo_move_to(cr, x, y + h);
    }

    /* left side */
    cairo_line_to(cr, x, y + radiusTopLeft);
    cairo_stroke (cr);

    if (radiusTopLeft > 0){
        cairo_arc (cr, x + radiusTopLeft, y + radiusTopLeft, radiusTopLeft, M_PI, 3.0 * M_PI / 2.0);
    } else {
        cairo_move_to(cr, x, y);
    }

    /* top side */
    cairo_line_to(cr, x + w - radiusTopRight, y);
    cairo_stroke (cr);

    cairo_destroy(cr);
}

/**
 * Set client shape
 * \param c Client
 * \param kind Shape kind - bounding or clip
 * \param surface Cairo surface with borders drawn on it
 * \param color In case of bounding surface, color of area around the border.
 *              In case of clip shape, color of area inside of the border.
 */
static void
set_client_shape(client_t* c, xcb_shape_sk_t kind, cairo_surface_t* surface, uint8_t color)
{
    int width = cairo_image_surface_get_width(surface);
    int height = cairo_image_surface_get_height(surface);
    int stride = cairo_image_surface_get_stride(surface);
    unsigned char* data = cairo_image_surface_get_data(surface);

    /* assume vertical symmetry, so number of rects is proportional to corner rad at top and bottom */
    const size_t max_rects = 2 * (c->corner_radius.top_left + c->corner_radius.bottom_left);
    xcb_rectangle_t rects[max_rects];
    size_t n_rect = 0;

    // Scan surface line by line, filling the array of rectangles
    int i, j;
    for (i = 0; i < height && n_rect < max_rects; ++i, data += stride) {
        for (j = 0; j < width && data[j] >= color; ++j) {
        }
        // We have reached border

        if (kind == XCB_SHAPE_SK_CLIP) {
            for (; j < width && data[j] < color; ++j) {
            }
            // We have reached contents of window inside of the border
        }

        // Calculate width. Assume that window has a vertical symmetry.
        int w = width - 2 * j;

        if (w > 0) {
            // Add it to rectangle list either by modifying the last rectangle or
            // by creating a new one
            xcb_rectangle_t *last = n_rect > 0 ? &rects[n_rect - 1] : NULL;
            if (last != NULL && last->y + last->height == i && last->width == w && last->x == j) {
                ++last->height;
            }
            else {
                rects[n_rect].x = j;
                rects[n_rect].y = i;
                rects[n_rect].width = w;
                rects[n_rect].height = 1;
                ++n_rect;
            }
        }
    }

    // set shape
    xcb_shape_rectangles(globalconf.connection, XCB_SHAPE_SO_SET, kind,
            0, c->window, -c->border_width, -c->border_width, n_rect, rects);
}

/**
 * Create pixmap from cairo surface and apply it as a border
 * \param c Client
 * \param surface Cairo surface
 * \param shm_info Shared memory segment containing surface
 */
static void
set_border_pixmap(client_t* c, cairo_surface_t* surface, const xcb_shm_segment_info_t* shm_info)
{
    int w = c->geometry.width;
    int h = c->geometry.height;
    int bw = c->border_width;

    xcb_screen_t* s = xutil_screen_get(globalconf.connection, c->phys_screen);

    xcb_pixmap_t pixmap = xcb_generate_id(globalconf.connection);
    xcb_create_pixmap(globalconf.connection, s->root_depth, pixmap, s->root, w, h);

    xcb_gcontext_t gc = xcb_generate_id(globalconf.connection);
    xcb_create_gc(globalconf.connection, gc, pixmap, 0, NULL);

    int stride = cairo_image_surface_get_stride(surface);
    uint8_t* data = cairo_image_surface_get_data(surface);

    xcb_image_t *img = xcb_image_create_native(globalconf.connection, stride / (s->root_depth >> 3), h,
                XCB_IMAGE_FORMAT_Z_PIXMAP, s->root_depth, NULL, stride * h, data);

    if (img != NULL) {
        // border image coordinates are from window origin, not from border origin.
        // we need to perform copy in 4 pieces

        // top left
        xcb_image_shm_put (globalconf.connection, pixmap, gc, img, *shm_info,
                0, 0, w - bw, h - bw, bw, bw, 0);
        // top side
        xcb_image_shm_put (globalconf.connection, pixmap, gc, img, *shm_info,
                bw, 0, 0, h - bw, w - bw, bw, 0);
        // left side
        xcb_image_shm_put (globalconf.connection, pixmap, gc, img, *shm_info,
                0, bw, w - bw, 0, bw, h - bw, 0);
        // bottom right
        xcb_image_shm_put (globalconf.connection, pixmap, gc, img, *shm_info,
                bw, bw, 0, 0, w - bw, h - bw, 0);
    }

    xcb_free_gc(globalconf.connection, gc);
    xcb_image_destroy(img);

    xcb_change_window_attributes(globalconf.connection, c->window,
            XCB_CW_BORDER_PIXMAP, &pixmap);

    xcb_free_pixmap(globalconf.connection, pixmap);
}

static int getCornerRadiusFromTable(lua_State *L, int stackPos, const char* name){
    int returnVal = luaA_getopt_number(L, stackPos, name, 0);

    return (returnVal>0)?returnVal:0;
}

#define CR_TOP_LEFT             "top_left"
#define CR_TOP_RIGHT            "top_right"
#define CR_BOTTOM_LEFT          "bottom_left"
#define CR_BOTTOM_RIGHT         "bottom_right"
#define CR_GRAY_FILL            0xee
/**
 * Set corner radius
 * @param L The Lua VM state.
 * @return corner radius object
  */
static int
luaA_client_corner_radius(lua_State *L)
{
    /* get client as "self" is first param */
    client_t *c = luaA_client_checkudata(L, 1);

    /* corners set as table in second param */
    /* if nil this is just a get */
    if(lua_gettop(L) == 2 && !lua_isnil(L, 2))
    {
        luaA_checktable(L, 2);
        c->corner_radius.top_left = getCornerRadiusFromTable(L, 2, CR_TOP_LEFT);
        c->corner_radius.top_right = getCornerRadiusFromTable(L, 2, CR_TOP_RIGHT);
        c->corner_radius.bottom_left = getCornerRadiusFromTable(L, 2, CR_BOTTOM_LEFT);
        c->corner_radius.bottom_right = getCornerRadiusFromTable(L, 2, CR_BOTTOM_RIGHT);

        /* enforce vertical symmetry, implementation limitation */
        if ((c->corner_radius.top_left != c->corner_radius.top_right) ||
                (c->corner_radius.bottom_left != c->corner_radius.bottom_right) ){
            LOGINFO("rounded corners require vertical symmetry at the moment");
            c->corner_radius.top_right = c->corner_radius.top_left;
            c->corner_radius.bottom_right = c->corner_radius.bottom_left;
        }

        /* if corners are all 0 then square corner path */
        if ( (c->corner_radius.top_left > 0) ||
                (c->corner_radius.top_right > 0) ||
                (c->corner_radius.bottom_left > 0) ||
                (c->corner_radius.bottom_right > 0) ){
            int stride = cairo_format_stride_for_width(CAIRO_FORMAT_A8, c->geometry.width);

            LOGDBG("setting rouned corners");

            /* shared memory for image */
            xcb_shm_segment_info_t shm_info;
            unsigned char* data = shm_attach(stride * c->geometry.height, &shm_info);

            if (data != NULL) {
                cairo_surface_t* surface = cairo_image_surface_create_for_data(
                        data, CAIRO_FORMAT_A8, c->geometry.width, c->geometry.height, stride);

                /* draw border, fill gray to calc clip below */
                draw_rounded_rect(surface,
                        c->corner_radius.top_left, c->corner_radius.top_right,
                        c->corner_radius.bottom_left, c->corner_radius.bottom_right,
                        c->border_width, c->border_color.pixel, CR_GRAY_FILL, true);

                /* set outside bounding shape */
                /* 0x7f is a custom tweaked value to search for the */
                /* border assuming the pixels are black */
                /* if we wanted to support any other color borders */
                /* this would need to be fixed */
                set_client_shape(c, XCB_SHAPE_SK_BOUNDING, surface, 0x7f);
                /*set inside clip shape */
                set_client_shape(c, XCB_SHAPE_SK_CLIP, surface, CR_GRAY_FILL);

                set_border_pixmap(c, surface, &shm_info);

                cairo_surface_destroy(surface);
                shm_detach(&shm_info);
            }

        } else {
            /* quick path for square corners */
            xcb_shape_mask(globalconf.connection, XCB_SHAPE_SO_SET, XCB_SHAPE_SK_BOUNDING,
                    c->window, -c->border_width, -c->border_width, XCB_NONE);
            xcb_shape_mask(globalconf.connection, XCB_SHAPE_SO_SET, XCB_SHAPE_SK_CLIP,
                    c->window, 0, 0, XCB_NONE);
        }
    }

    /* return corner radius table */
    lua_createtable(L, 0, 4);
    lua_pushnumber(L, c->corner_radius.top_left);
    lua_setfield(L, -2, CR_TOP_LEFT);
    lua_pushnumber(L, c->corner_radius.top_right);
    lua_setfield(L, -2, CR_TOP_RIGHT);
    lua_pushnumber(L, c->corner_radius.bottom_left);
    lua_setfield(L, -2, CR_BOTTOM_LEFT);
    lua_pushnumber(L, c->corner_radius.bottom_right);
    lua_setfield(L, -2, CR_BOTTOM_RIGHT);
    return 1;
}

/**
 * Get the window Id.
 */
static int
luaA_client_get_windowId(lua_State *L)
{
    /* clint we are checking */
    client_t *c = luaA_client_checkudata(L, 1);
    lua_pushnumber(L, c->window);
    return 1;
}
#endif // LAB126

static int
luaA_client_set_ontop(lua_State *L, client_t *c)
{
    client_set_ontop(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_below(lua_State *L, client_t *c)
{
    client_set_below(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_above(lua_State *L, client_t *c)
{
    client_set_above(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_urgent(lua_State *L, client_t *c)
{
    client_set_urgent(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_border_color(lua_State *L, client_t *c)
{
    size_t len;
    const char *buf;
    if((buf = luaL_checklstring(L, -1, &len))
       && xcolor_init_reply(xcolor_init_unchecked(&c->border_color, buf, len)))
    {
        xcb_change_window_attributes(globalconf.connection, c->window,
                                     XCB_CW_BORDER_PIXEL, &c->border_color.pixel);
        luaA_object_emit_signal(L, -3, "property::border_color", 0);
    }
    return 0;
}

static int
luaA_client_set_titlebar(lua_State *L, client_t *c)
{
    if(lua_isnil(L, -1))
        titlebar_client_detach(c);
    else
        titlebar_client_attach(c);
    return 0;
}

#ifdef LAB126

static int
luaA_client_set_transient_for_dont_clip_bounds(lua_State *L)
{

    /* transientFor */
    client_t *c2 = luaA_client_checkudata(L, 2);

    client_set_transient_for(L, 1, c2);

    return 0;
}


static int
luaA_client_set_transient_for(lua_State *L, client_t *c)
{
    client_t *transient_for = lua_isnil(L, -1) ? NULL : luaA_client_checkudata(L, -1);

    if (transient_for != NULL)
    {
        xcb_shape_combine(globalconf.connection, XCB_SHAPE_SO_SET,
                XCB_SHAPE_SK_BOUNDING, XCB_SHAPE_SK_CLIP, c->window,
                transient_for->border_width + transient_for->geometry.x - c->geometry.x,
                transient_for->border_width + transient_for->geometry.y - c->geometry.y,
                transient_for->window);
    }
    else
    {
        xcb_shape_mask(globalconf.connection, XCB_SHAPE_SO_SET, XCB_SHAPE_SK_BOUNDING,
                c->window, 0, 0, XCB_NONE);
    }

    client_set_transient_for(L, -3, transient_for);

    return 0;
}
#endif

static int
luaA_client_set_skip_taskbar(lua_State *L, client_t *c)
{
    client_set_skip_taskbar(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

#ifdef LAB126
static int
luaA_client_set_signalHandled(lua_State *L, client_t *c)
{
    bool signalHandled = luaA_checkboolean(L, -1);
    c->signalHandled = signalHandled;
    return 0;
}

static int
luaA_client_set_normal(lua_State *L, client_t *c)
{
    client_set_normal(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_get_normal(lua_State *L, client_t *c)
{
    bool isNormal = !(c->ontop || c->above || c->below || c->hiddenLayer);
    lua_pushboolean(L, isNormal);
    return 1;
}

static int
luaA_client_set_hiddenLayer(lua_State *L, client_t *c)
{
    client_set_hiddenLayer(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_dialogLayer(lua_State *L, client_t *c)
{
    client_set_dialogLayer(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_kbLayer(lua_State *L, client_t *c)
{
    client_set_kbLayer(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_save_under(lua_State *L, client_t *c)
{
    client_set_save_under(L, -3, luaA_checkboolean(L, -1));
    return 0;
}

static int
luaA_client_set_backing_store(lua_State *L, client_t *c)
{
    client_set_backing_store(L, -3, luaL_checknumber(L, -1));
    return 0;
}

void
client_damage(client_t *c, area_t area)
{
    luaA_object_push(globalconf.L, c);
    lua_pushinteger(globalconf.L, area.x);
    lua_pushinteger(globalconf.L, area.y);
    lua_pushinteger(globalconf.L, area.width);
    lua_pushinteger(globalconf.L, area.height);
    luaA_class_emit_signal(globalconf.L, &client_class, "damage", 5);
}

#endif

static int
luaA_client_get_name(lua_State *L, client_t *c)
{
    lua_pushstring(L, c->name ? c->name : c->alt_name);
    return 1;
}

static int
luaA_client_get_icon_name(lua_State *L, client_t *c)
{
    lua_pushstring(L, c->icon_name ? c->icon_name : c->alt_icon_name);
    return 1;
}

LUA_OBJECT_EXPORT_PROPERTY(client, client_t, class, lua_pushstring)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, instance, lua_pushstring)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, machine, lua_pushstring)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, role, lua_pushstring)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, transient_for, luaA_object_push)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, skip_taskbar, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, window, lua_pushnumber)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, leader_window, lua_pushnumber)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, group_window, lua_pushnumber)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, pid, lua_pushnumber)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, hidden, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, minimized, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, fullscreen, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, modal, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, ontop, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, urgent, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, above, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, below, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, sticky, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, size_hints_honor, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, maximized_horizontal, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, maximized_vertical, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, opacity, lua_pushnumber)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, border_width, lua_pushnumber)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, border_color, luaA_pushxcolor)
#ifdef LAB126
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, nofocus, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, signalHandled, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, hiddenLayer, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, dialogLayer, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, kbLayer, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, save_under, lua_pushboolean)
LUA_OBJECT_EXPORT_PROPERTY(client, client_t, backing_store, lua_pushnumber)
#endif


static int
luaA_client_get_content(lua_State *L, client_t *c)
{
    xcb_image_t *ximage = xcb_image_get(globalconf.connection,
                                        c->window,
                                        0, 0,
                                        c->geometries.internal.width,
                                        c->geometries.internal.height,
                                        ~0, XCB_IMAGE_FORMAT_Z_PIXMAP);
    int retval = 0;

    if(ximage)
    {
        if(ximage->bpp >= 24)
        {
            uint32_t *data = p_alloca(uint32_t, ximage->width * ximage->height);

            for(int y = 0; y < ximage->height; y++)
                for(int x = 0; x < ximage->width; x++)
                {
                    data[y * ximage->width + x] = xcb_image_get_pixel(ximage, x, y);
                    data[y * ximage->width + x] |= 0xff000000; /* set alpha to 0xff */
                }

            retval = image_new_from_argb32(ximage->width, ximage->height, data);
        }
        xcb_image_destroy(ximage);
    }

    return retval;
}

static int
luaA_client_get_type(lua_State *L, client_t *c)
{
    switch(c->type)
    {
      case WINDOW_TYPE_DESKTOP:
        lua_pushliteral(L, "desktop");
        break;
      case WINDOW_TYPE_DOCK:
        lua_pushliteral(L, "dock");
        break;
      case WINDOW_TYPE_SPLASH:
        lua_pushliteral(L, "splash");
        break;
      case WINDOW_TYPE_DIALOG:
        lua_pushliteral(L, "dialog");
        break;
      case WINDOW_TYPE_MENU:
        lua_pushliteral(L, "menu");
        break;
      case WINDOW_TYPE_TOOLBAR:
        lua_pushliteral(L, "toolbar");
        break;
      case WINDOW_TYPE_UTILITY:
        lua_pushliteral(L, "utility");
        break;
      case WINDOW_TYPE_DROPDOWN_MENU:
        lua_pushliteral(L, "dropdown_menu");
        break;
      case WINDOW_TYPE_POPUP_MENU:
        lua_pushliteral(L, "popup_menu");
        break;
      case WINDOW_TYPE_TOOLTIP:
        lua_pushliteral(L, "tooltip");
        break;
      case WINDOW_TYPE_NOTIFICATION:
        lua_pushliteral(L, "notification");
        break;
      case WINDOW_TYPE_COMBO:
        lua_pushliteral(L, "combo");
        break;
      case WINDOW_TYPE_DND:
        lua_pushliteral(L, "dnd");
        break;
      case WINDOW_TYPE_NORMAL:
        lua_pushliteral(L, "normal");
        break;
    }
    return 1;
}

static int
luaA_client_get_screen(lua_State *L, client_t *c)
{
    if(!c->screen)
        return 0;
    lua_pushnumber(L, 1 + screen_array_indexof(&globalconf.screens, c->screen));
    return 1;
}

static int
luaA_client_get_icon(lua_State *L, client_t *c)
{
    return luaA_object_push_item(L, -2, c->icon);
}

static int
luaA_client_get_titlebar(lua_State *L, client_t *c)
{
    return luaA_object_push(L, c->titlebar);
}

static int
luaA_client_get_size_hints(lua_State *L, client_t *c)
{
    const char *u_or_p = NULL;

    lua_createtable(L, 0, 1);

    if(c->size_hints.flags & XCB_SIZE_HINT_US_POSITION)
        u_or_p = "user_position";
    else if(c->size_hints.flags & XCB_SIZE_HINT_P_POSITION)
        u_or_p = "program_position";

    if(u_or_p)
    {
        lua_createtable(L, 0, 2);
        lua_pushnumber(L, c->size_hints.x);
        lua_setfield(L, -2, "x");
        lua_pushnumber(L, c->size_hints.y);
        lua_setfield(L, -2, "y");
        lua_setfield(L, -2, u_or_p);
        u_or_p = NULL;
    }

    if(c->size_hints.flags & XCB_SIZE_HINT_US_SIZE)
        u_or_p = "user_size";
    else if(c->size_hints.flags & XCB_SIZE_HINT_P_SIZE)
        u_or_p = "program_size";

    if(u_or_p)
    {
        lua_createtable(L, 0, 2);
        lua_pushnumber(L, c->size_hints.width);
        lua_setfield(L, -2, "width");
        lua_pushnumber(L, c->size_hints.height);
        lua_setfield(L, -2, "height");
        lua_setfield(L, -2, u_or_p);
    }

    if(c->size_hints.flags & XCB_SIZE_HINT_P_MIN_SIZE)
    {
        lua_pushnumber(L, c->size_hints.min_width);
        lua_setfield(L, -2, "min_width");
        lua_pushnumber(L, c->size_hints.min_height);
        lua_setfield(L, -2, "min_height");
    }

    if(c->size_hints.flags & XCB_SIZE_HINT_P_MAX_SIZE)
    {
        lua_pushnumber(L, c->size_hints.max_width);
        lua_setfield(L, -2, "max_width");
        lua_pushnumber(L, c->size_hints.max_height);
        lua_setfield(L, -2, "max_height");
    }

    if(c->size_hints.flags & XCB_SIZE_HINT_P_RESIZE_INC)
    {
        lua_pushnumber(L, c->size_hints.width_inc);
        lua_setfield(L, -2, "width_inc");
        lua_pushnumber(L, c->size_hints.height_inc);
        lua_setfield(L, -2, "height_inc");
    }

    if(c->size_hints.flags & XCB_SIZE_HINT_P_ASPECT)
    {
        lua_pushnumber(L, c->size_hints.min_aspect_num);
        lua_setfield(L, -2, "min_aspect_num");
        lua_pushnumber(L, c->size_hints.min_aspect_den);
        lua_setfield(L, -2, "min_aspect_den");
        lua_pushnumber(L, c->size_hints.max_aspect_num);
        lua_setfield(L, -2, "max_aspect_num");
        lua_pushnumber(L, c->size_hints.max_aspect_den);
        lua_setfield(L, -2, "max_aspect_den");
    }

    if(c->size_hints.flags & XCB_SIZE_HINT_BASE_SIZE)
    {
        lua_pushnumber(L, c->size_hints.base_width);
        lua_setfield(L, -2, "base_width");
        lua_pushnumber(L, c->size_hints.base_height);
        lua_setfield(L, -2, "base_height");
    }

    if(c->size_hints.flags & XCB_SIZE_HINT_P_WIN_GRAVITY)
    {
        switch(c->size_hints.win_gravity)
        {
          default:
            lua_pushliteral(L, "north_west");
            break;
          case XCB_GRAVITY_NORTH:
            lua_pushliteral(L, "north");
            break;
          case XCB_GRAVITY_NORTH_EAST:
            lua_pushliteral(L, "north_east");
            break;
          case XCB_GRAVITY_WEST:
            lua_pushliteral(L, "west");
            break;
          case XCB_GRAVITY_CENTER:
            lua_pushliteral(L, "center");
            break;
          case XCB_GRAVITY_EAST:
            lua_pushliteral(L, "east");
            break;
          case XCB_GRAVITY_SOUTH_WEST:
            lua_pushliteral(L, "south_west");
            break;
          case XCB_GRAVITY_SOUTH:
            lua_pushliteral(L, "south");
            break;
          case XCB_GRAVITY_SOUTH_EAST:
            lua_pushliteral(L, "south_east");
            break;
          case XCB_GRAVITY_STATIC:
            lua_pushliteral(L, "static");
            break;
        }
        lua_setfield(L, -2, "win_gravity");
    }

    return 1;
}

/** Get or set mouse buttons bindings for a client.
 * \param L The Lua VM state.
 * \return The number of element pushed on stack.
 * \luastack
 * \lvalue A client.
 * \lparam An array of mouse button bindings objects, or nothing.
 * \return The array of mouse button bindings objects of this client.
 */
static int
luaA_client_buttons(lua_State *L)
{
    client_t *client = luaA_client_checkudata(L, 1);
    button_array_t *buttons = &client->buttons;

    if(lua_gettop(L) == 2)
    {
        luaA_button_array_set(L, 1, 2, buttons);
        luaA_object_emit_signal(L, 1, "property::buttons", 0);
        window_buttons_grab(client->window, &client->buttons);
    }

    return luaA_button_array_get(L, 1, buttons);
}

/** Get or set keys bindings for a client.
 * \param L The Lua VM state.
 * \return The number of element pushed on stack.
 * \luastack
 * \lvalue A client.
 * \lparam An array of key bindings objects, or nothing.
 * \return The array of key bindings objects of this client.
 */
static int
luaA_client_keys(lua_State *L)
{
    client_t *c = luaA_client_checkudata(L, 1);
    key_array_t *keys = &c->keys;

    if(lua_gettop(L) == 2)
    {
        luaA_key_array_set(L, 1, 2, keys);
        luaA_object_emit_signal(L, 1, "property::keys", 0);
        xcb_ungrab_key(globalconf.connection, XCB_GRAB_ANY, c->window, XCB_BUTTON_MASK_ANY);
        window_grabkeys(c->window, keys);
    }

    return luaA_key_array_get(L, 1, keys);
}

/* Client module.
 * \param L The Lua VM state.
 * \return The number of pushed elements.
 */
static int
luaA_client_module_index(lua_State *L)
{
    size_t len;
    const char *buf = luaL_checklstring(L, 2, &len);

    switch(a_tokenize(buf, len))
    {
      case A_TK_FOCUS:
        return luaA_object_push(globalconf.L, globalconf.screen_focus->client_focus);
        break;
      default:
        return 0;
    }
}

/* Client module new index.
 * \param L The Lua VM state.
 * \return The number of pushed elements.
 */
static int
luaA_client_module_newindex(lua_State *L)
{
    size_t len;
    const char *buf = luaL_checklstring(L, 2, &len);
    client_t *c;

    switch(a_tokenize(buf, len))
    {
      case A_TK_FOCUS:
        c = luaA_client_checkudata(L, 3);
        client_focus(c);
        break;
      default:
        break;
    }

    return 0;
}

void
client_class_setup(lua_State *L)
{

#ifdef LAB126
    luaL_register(L, "clientData", clientData);
    lua_pop(L, 1);
#endif

    static const struct luaL_reg client_methods[] =
    {
        LUA_CLASS_METHODS(client)
        { "get", luaA_client_get },
        { "__index", luaA_client_module_index },
        { "__newindex", luaA_client_module_newindex },
#ifdef LAB126
        { "log_all_clients", luaA_log_all_clients },
        { "force_restack", luaA_force_restack },
        { "validate_stacking_order", luaA_validate_client_validate_stacking_order },
        { "get_client_at", luaA_get_client_at },
        { "get_client_by_windowId", luaA_get_client_by_windowId },
#endif
        { NULL, NULL }
    };

    static const struct luaL_reg client_meta[] =
    {
        LUA_OBJECT_META(client)
        LUA_CLASS_META
        { "buttons", luaA_client_buttons },
        { "keys", luaA_client_keys },
        { "isvisible", luaA_client_isvisible },
        { "geometry", luaA_client_geometry },
        { "struts", luaA_client_struts },
        { "tags", luaA_client_tags },
        { "kill", luaA_client_kill },
        { "swap", luaA_client_swap },
        { "raise", luaA_client_raise },
        { "lower", luaA_client_lower },
        { "redraw", luaA_client_redraw },
        { "unmanage", luaA_client_unmanage },
        { "__gc", luaA_client_gc },
#ifdef LAB126
        { "is_obscured", luaA_client_is_obscured },
        { "is_above", luaA_client_is_above },
        { "set_transient_for_dont_clip_bounds", luaA_client_set_transient_for_dont_clip_bounds},
        { "is_obscured_by", luaA_client_is_obscured_by },
        { "sendKeyEvent", luaA_client_sendKeyEvent },
        { "sendButtonEvent", luaA_client_sendButtonEvent },
        { "getWindowId", luaA_client_get_windowId},
        { "destroy", luaA_client_destroy },
        { "set_layer_without_restack", luaA_client_set_layer_without_restack },
        { "corner_radius", luaA_client_corner_radius },
#endif
        { NULL, NULL }
    };

    luaA_class_setup(L, &client_class, "client", (lua_class_allocator_t) client_new,
                     luaA_class_index_miss_property, luaA_class_newindex_miss_property,
                     client_methods, client_meta);
    luaA_class_add_property(&client_class, A_TK_NAME,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_name,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_TRANSIENT_FOR,
#ifdef LAB126
                            (lua_class_propfunc_t) luaA_client_set_transient_for,
                            (lua_class_propfunc_t) luaA_client_get_transient_for,
                            (lua_class_propfunc_t) luaA_client_set_transient_for);
#else
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_transient_for,
                            NULL);
#endif
    luaA_class_add_property(&client_class, A_TK_SKIP_TASKBAR,
                            (lua_class_propfunc_t) luaA_client_set_skip_taskbar,
                            (lua_class_propfunc_t) luaA_client_get_skip_taskbar,
                            (lua_class_propfunc_t) luaA_client_set_skip_taskbar);
    luaA_class_add_property(&client_class, A_TK_CONTENT,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_content,
                            NULL);
#ifdef LAB126
    luaA_class_add_property(&client_class, A_TK_NORMAL,
                            (lua_class_propfunc_t) luaA_client_set_normal,
                            (lua_class_propfunc_t) luaA_client_get_normal,
                            (lua_class_propfunc_t) luaA_client_set_normal);
    luaA_class_add_property(&client_class, A_TK_HIDDENLAYER,
                            (lua_class_propfunc_t) luaA_client_set_hiddenLayer,
                            (lua_class_propfunc_t) luaA_client_get_hiddenLayer,
                            (lua_class_propfunc_t) luaA_client_set_hiddenLayer);
    luaA_class_add_property(&client_class, A_TK_DIALOGLAYER,
                            (lua_class_propfunc_t) luaA_client_set_dialogLayer,
                            (lua_class_propfunc_t) luaA_client_get_dialogLayer,
                            (lua_class_propfunc_t) luaA_client_set_dialogLayer);
    luaA_class_add_property(&client_class, A_TK_KBLAYER,
                            (lua_class_propfunc_t) luaA_client_set_kbLayer,
                            (lua_class_propfunc_t) luaA_client_get_kbLayer,
                            (lua_class_propfunc_t) luaA_client_set_kbLayer);
#endif
    luaA_class_add_property(&client_class, A_TK_TYPE,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_type,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_CLASS,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_class,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_INSTANCE,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_instance,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_ROLE,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_role,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_PID,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_pid,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_WINDOW,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_window,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_LEADER_WINDOW,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_leader_window,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_MACHINE,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_machine,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_ICON_NAME,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_icon_name,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_SCREEN,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_screen,
                            (lua_class_propfunc_t) luaA_client_set_screen);
    luaA_class_add_property(&client_class, A_TK_HIDDEN,
                            (lua_class_propfunc_t) luaA_client_set_hidden,
                            (lua_class_propfunc_t) luaA_client_get_hidden,
                            (lua_class_propfunc_t) luaA_client_set_hidden);
    luaA_class_add_property(&client_class, A_TK_MINIMIZED,
                            (lua_class_propfunc_t) luaA_client_set_minimized,
                            (lua_class_propfunc_t) luaA_client_get_minimized,
                            (lua_class_propfunc_t) luaA_client_set_minimized);
    luaA_class_add_property(&client_class, A_TK_FULLSCREEN,
                            (lua_class_propfunc_t) luaA_client_set_fullscreen,
                            (lua_class_propfunc_t) luaA_client_get_fullscreen,
                            (lua_class_propfunc_t) luaA_client_set_fullscreen);
    luaA_class_add_property(&client_class, A_TK_MODAL,
                            (lua_class_propfunc_t) luaA_client_set_modal,
                            (lua_class_propfunc_t) luaA_client_get_modal,
                            (lua_class_propfunc_t) luaA_client_set_modal);
    luaA_class_add_property(&client_class, A_TK_GROUP_WINDOW,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_group_window,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_MAXIMIZED_HORIZONTAL,
                            (lua_class_propfunc_t) luaA_client_set_maximized_horizontal,
                            (lua_class_propfunc_t) luaA_client_get_maximized_horizontal,
                            (lua_class_propfunc_t) luaA_client_set_maximized_horizontal);
    luaA_class_add_property(&client_class, A_TK_MAXIMIZED_VERTICAL,
                            (lua_class_propfunc_t) luaA_client_set_maximized_vertical,
                            (lua_class_propfunc_t) luaA_client_get_maximized_vertical,
                            (lua_class_propfunc_t) luaA_client_set_maximized_vertical);
    luaA_class_add_property(&client_class, A_TK_ICON,
                            (lua_class_propfunc_t) luaA_client_set_icon,
                            (lua_class_propfunc_t) luaA_client_get_icon,
                            (lua_class_propfunc_t) luaA_client_set_icon);
#ifdef LAB126
    luaA_class_add_property(&client_class, A_TK_SIGNALHANDLED,
                            (lua_class_propfunc_t) luaA_client_set_signalHandled,
                            (lua_class_propfunc_t) luaA_client_get_signalHandled,
                            (lua_class_propfunc_t) luaA_client_set_signalHandled);
    luaA_class_add_property(&client_class, A_TK_NOFOCUS,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_nofocus,
                            NULL);
    luaA_class_add_property(&client_class, A_TK_SAVE_UNDER,
                            (lua_class_propfunc_t) luaA_client_set_save_under,
                            (lua_class_propfunc_t) luaA_client_get_save_under,
                            (lua_class_propfunc_t) luaA_client_set_save_under);
    luaA_class_add_property(&client_class, A_TK_BACKING_STORE,
                            (lua_class_propfunc_t) luaA_client_set_backing_store,
                            (lua_class_propfunc_t) luaA_client_get_backing_store,
                            (lua_class_propfunc_t) luaA_client_set_backing_store);
#endif
    luaA_class_add_property(&client_class, A_TK_OPACITY,
                            (lua_class_propfunc_t) luaA_client_set_opacity,
                            (lua_class_propfunc_t) luaA_client_get_opacity,
                            (lua_class_propfunc_t) luaA_client_set_opacity);
    luaA_class_add_property(&client_class, A_TK_ONTOP,
                            (lua_class_propfunc_t) luaA_client_set_ontop,
                            (lua_class_propfunc_t) luaA_client_get_ontop,
                            (lua_class_propfunc_t) luaA_client_set_ontop);
    luaA_class_add_property(&client_class, A_TK_ABOVE,
                            (lua_class_propfunc_t) luaA_client_set_above,
                            (lua_class_propfunc_t) luaA_client_get_above,
                            (lua_class_propfunc_t) luaA_client_set_above);
    luaA_class_add_property(&client_class, A_TK_BELOW,
                            (lua_class_propfunc_t) luaA_client_set_below,
                            (lua_class_propfunc_t) luaA_client_get_below,
                            (lua_class_propfunc_t) luaA_client_set_below);
    luaA_class_add_property(&client_class, A_TK_STICKY,
                            (lua_class_propfunc_t) luaA_client_set_sticky,
                            (lua_class_propfunc_t) luaA_client_get_sticky,
                            (lua_class_propfunc_t) luaA_client_set_sticky);
    luaA_class_add_property(&client_class, A_TK_SIZE_HINTS_HONOR,
                            (lua_class_propfunc_t) luaA_client_set_size_hints_honor,
                            (lua_class_propfunc_t) luaA_client_get_size_hints_honor,
                            (lua_class_propfunc_t) luaA_client_set_size_hints_honor);
    luaA_class_add_property(&client_class, A_TK_BORDER_WIDTH,
                            (lua_class_propfunc_t) luaA_client_set_border_width,
                            (lua_class_propfunc_t) luaA_client_get_border_width,
                            (lua_class_propfunc_t) luaA_client_set_border_width);
    luaA_class_add_property(&client_class, A_TK_BORDER_COLOR,
                            (lua_class_propfunc_t) luaA_client_set_border_color,
                            (lua_class_propfunc_t) luaA_client_get_border_color,
                            (lua_class_propfunc_t) luaA_client_set_border_color);
    luaA_class_add_property(&client_class, A_TK_TITLEBAR,
                            (lua_class_propfunc_t) luaA_client_set_titlebar,
                            (lua_class_propfunc_t) luaA_client_get_titlebar,
                            (lua_class_propfunc_t) luaA_client_set_titlebar);
    luaA_class_add_property(&client_class, A_TK_URGENT,
                            (lua_class_propfunc_t) luaA_client_set_urgent,
                            (lua_class_propfunc_t) luaA_client_get_urgent,
                            (lua_class_propfunc_t) luaA_client_set_urgent);
    luaA_class_add_property(&client_class, A_TK_SIZE_HINTS,
                            NULL,
                            (lua_class_propfunc_t) luaA_client_get_size_hints,
                            NULL);

}

// vim: filetype=c:expandtab:shiftwidth=4:tabstop=8:softtabstop=4:encoding=utf-8:textwidth=80

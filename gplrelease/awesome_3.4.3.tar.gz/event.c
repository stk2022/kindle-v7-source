/*
 * event.c - event handlers
 *
 * Copyright © 2007-2008 Julien Danjou <julien@danjou.info>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

#include <xcb/xcb.h>
#include <xcb/randr.h>
#include <xcb/xcb_atom.h>
#include <xcb/xcb_icccm.h>
#include <xcb/xcb_event.h>
#include <sys/time.h>

#include "awesome.h"
#include "event.h"
#include "tag.h"
#include "window.h"
#include "ewmh.h"
#include "client.h"
#include "widget.h"
#include "titlebar.h"
#include "key.h"
#include "keygrabber.h"
#include "mousegrabber.h"
#include "luaa.h"
#include "systray.h"
#include "screen.h"
#include "common/atoms.h"
#include "common/xutil.h"
#include "common/logger.h"

#define DO_EVENT_HOOK_CALLBACK(type, xcbtype, xcbeventprefix, arraytype, match) \
    static void \
    event_##xcbtype##_callback(xcb_##xcbtype##_press_event_t *ev, \
                               arraytype *arr, \
                               int oud, \
                               int nargs, \
                               void *data) \
    { \
        int abs_oud = oud < 0 ? ((lua_gettop(globalconf.L) + 1) + oud) : oud; \
        int item_matching = 0; \
        foreach(item, *arr) \
            if(match(ev, *item, data)) \
            { \
                if(oud) \
                    luaA_object_push_item(globalconf.L, abs_oud, *item); \
                else \
                    luaA_object_push(globalconf.L, *item); \
                item_matching++; \
            } \
        for(; item_matching > 0; item_matching--) \
        { \
            switch(ev->response_type) \
            { \
              case xcbeventprefix##_PRESS: \
                for(int i = 0; i < nargs; i++) \
                    lua_pushvalue(globalconf.L, - nargs - item_matching); \
                luaA_object_emit_signal(globalconf.L, - nargs - 1, "press", nargs); \
                break; \
              case xcbeventprefix##_RELEASE: \
                for(int i = 0; i < nargs; i++) \
                    lua_pushvalue(globalconf.L, - nargs - item_matching); \
                luaA_object_emit_signal(globalconf.L, - nargs - 1, "release", nargs); \
                break; \
            } \
            lua_pop(globalconf.L, 1); \
        } \
        lua_pop(globalconf.L, nargs); \
    }

#ifdef LAB126
static GHashTable *WMFreezeDetectionMgr = NULL;
#endif

static bool
event_key_match(xcb_key_press_event_t *ev, keyb_t *k, void *data)
{
    assert(data);
    xcb_keysym_t keysym = *(xcb_keysym_t *) data;
    return (((k->keycode && ev->detail == k->keycode)
             || (k->keysym && keysym == k->keysym))
            && (k->modifiers == XCB_BUTTON_MASK_ANY || k->modifiers == ev->state));
}

static bool
event_button_match(xcb_button_press_event_t *ev, button_t *b, void *data)
{
    return ((!b->button || ev->detail == b->button)
            && (b->modifiers == XCB_BUTTON_MASK_ANY || b->modifiers == ev->state));
}

DO_EVENT_HOOK_CALLBACK(button_t, button, XCB_BUTTON, button_array_t, event_button_match)
DO_EVENT_HOOK_CALLBACK(keyb_t, key, XCB_KEY, key_array_t, event_key_match)

/** Handle an event with mouse grabber if needed
 * \param x The x coordinate.
 * \param y The y coordinate.
 * \param mask The mask buttons.
 * \return True if the event was handled.
 */
static bool
event_handle_mousegrabber(int x, int y, uint16_t mask)
{
    if(globalconf.mousegrabber != LUA_REFNIL)
    {
        lua_rawgeti(globalconf.L, LUA_REGISTRYINDEX, globalconf.mousegrabber);
        mousegrabber_handleevent(globalconf.L, x, y, mask);
        if(lua_pcall(globalconf.L, 1, 1, 0))
        {
            warn("error running function: %s", lua_tostring(globalconf.L, -1));
            luaA_mousegrabber_stop(globalconf.L);
        }
        else if(!lua_isboolean(globalconf.L, -1) || !lua_toboolean(globalconf.L, -1))
            luaA_mousegrabber_stop(globalconf.L);
        lua_pop(globalconf.L, 1);  /* pop returned value */
        return true;
    }

    return false;
}

#ifdef LAB126
/**
 * Stop all timers and free data before removing from hashtable
 */
static void free_freeze_detection_data(gpointer p) {
    WMFreezeDetectionData *data = p;
    ev_timer_stop(globalconf.loop, data->ev_damage_timeout);
    free(data->ev_damage_timeout);
    if (data->pingRequest) {
        ev_timer_stop(globalconf.loop, data->pingRequest->ev_ping_timeout);
        free(data->pingRequest->ev_ping_timeout);
        free(data->pingRequest);
    }
    free(data);
}

/**
 * We did not receive a response from the client to our "ping". The client is
 * being unresponsive and needs to be force killed at this point
 */
static void wm_ping_timeout_cb (struct ev_loop *loop, struct ev_timer *w, int revents) {
    WMFreezeDetectionData *data = w->data;
    //Device is assumed to be "frozen" at this point.
    //Delegate freeze handling to an external script that decides what is to be
    //done depending on the process that owns the "frozen" window.
    LOGINFO("++++Request with timestamp timed out: %d, %d; client_pid = %d", data->pingRequest->sec, data->pingRequest->nsec, data->client->pid);
    char pidStr[10];
    snprintf(pidStr, 10, "%d", data->client->pid);
    char *argv[] = { "/usr/bin/handle_freeze", pidStr, NULL };
    GError *error;
    if (! g_spawn_async (NULL, argv, NULL, 0, NULL, NULL, NULL, &error)) {
        LOGINFO("Spawning freeze handling script failed with error : %s", error->message);
        g_error_free(error);
    }

    //TODO: I am just clearing this entry from the  table for now. We should decide what needs to
    //happen on detecting a frozen window.
    g_hash_table_remove(WMFreezeDetectionMgr, GUINT_TO_POINTER(data->client->window));
}

/** 
 * Ping the client window
 *  \param c The client to ping
 */
static void wm_ping_client(WMFreezeDetectionData *data) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);

    xcb_client_message_event_t ev;
    ev.response_type = XCB_CLIENT_MESSAGE;
    ev.format = 32;
    ev.window = data->client->window;
    ev.data.data32[1] = ts.tv_sec;
    ev.data.data32[2] = ts.tv_nsec;
    //When the client responds, this field is expected to be unchanged so that
    //we can identify the request from the hashtable with this as the key.
    ev.data.data32[3] = data->client->window;
    ev.type = WM_PROTOCOLS;
    ev.data.data32[0] = _NET_WM_PING;
    xcb_send_event(globalconf.connection, false, data->client->window,
                       XCB_EVENT_MASK_NO_EVENT, (char *) &ev);

    WMPingRequest *request = g_new(WMPingRequest, 1);
    request->sec = ts.tv_sec;
    request->nsec = ts.tv_nsec;
    ev_timer *ev_timeout = g_new(ev_timer, 1);
    ev_timer_init(ev_timeout, wm_ping_timeout_cb, WM_PING_TIMEOUT, 0.);
    ev_timeout->data = data;
    request->ev_ping_timeout = ev_timeout;
    data->pingRequest = request;
    data->state = WAITING_FOR_PONG;
    ev_timer_start(globalconf.loop, ev_timeout);

    LOGDBG("++++Sent ping request with timestamp : %d, %d", ev.data.data32[1], ev.data.data32[2]);
}

/**
 * Process reply to the ping that was sent
 * \param ev This is the xcb_client_message_event_t* that was received
 */
static void process_wm_pong (xcb_client_message_event_t *ev) {
    LOGDBG("++++Received reply for ping with timestamp : %d, %d", ev->data.data32[1], ev->data.data32[2]);
    Window win = ev->data.data32[3];
    if (g_hash_table_lookup(WMFreezeDetectionMgr, GUINT_TO_POINTER(win))) {
        g_hash_table_remove(WMFreezeDetectionMgr, GUINT_TO_POINTER(win));
    } else {
        LOGDBG("++++Something went wrong. Unable to find corresponding request in table");
    }
}

/**
 * We did not get a damage from this window. Hence, we send a "ping" and wait
 * for the client to respond to this message
 */
static void wm_damage_timeout_cb (struct ev_loop *loop, struct ev_timer *w, int revents) {
    WMFreezeDetectionData *data = w->data;
    LOGDBG("++++Damage not satisfied for window %d, sending ping", data->client->window);
    wm_ping_client(data);
}

/**
 * Remove this client from hashtable as we either got a damage from this window
 * indicating that this is still responding or this window is getting unmapped.
 * \param c The client_t* of the client
 */
static void stop_waiting_for_client_response(client_t *c) {
    if (g_hash_table_lookup(WMFreezeDetectionMgr, GUINT_TO_POINTER(c->window))) {
        g_hash_table_remove(WMFreezeDetectionMgr, GUINT_TO_POINTER(c->window));
    }     
}

static void wait_for_damage_from_client(client_t *c) {
    if (! g_hash_table_lookup(WMFreezeDetectionMgr, GUINT_TO_POINTER(c->window))) {

        WMFreezeDetectionData *data = g_new(WMFreezeDetectionData, 1);
        data->client = c;
        data->state = WAITING_FOR_DAMAGE;
        data->pingRequest = NULL;

        ev_timer *ev_timeout = g_new(ev_timer, 1);
        ev_timer_init(ev_timeout, wm_damage_timeout_cb, WM_DAMAGE_TIMEOUT, 0.);
        ev_timeout->data = data;
        data->ev_damage_timeout = ev_timeout;
        ev_timer_start(globalconf.loop, ev_timeout);

        g_hash_table_insert(WMFreezeDetectionMgr, GUINT_TO_POINTER(c->window), (gpointer) data);

        LOGDBG("++++WAITING FOR DAMAGE FROM WINDOW %d", c->window);
    } 
}

#endif

/** The button press event handler.
 * \param data The type of mouse event.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_button(void *data, xcb_connection_t *connection, xcb_button_press_event_t *ev)
{
    int screen;
    const int nb_screen = xcb_setup_roots_length(xcb_get_setup(connection));
    client_t *c;
    wibox_t *wibox;

    LOGDBG("+++++ event_handle_button %d, %d, %d, %d %d",
            ev->detail, ev->state, ev->response_type, ev->time, ev->sequence);
    LOGPRIVATE("button location %d:%d", ev->event_x, ev->event_y);

#ifdef LOGGING_PERF
    /*set up perf log on event processing*/
    struct timeval timeStart;
    /* get start timestamp */
    gettimeofday(&timeStart, NULL);
#endif


    if(event_handle_mousegrabber(ev->root_x, ev->root_y, 1 << (ev->detail - 1 + 8)))
        return 0;

    /* ev->state is
     * button status (8 bits) + modifiers status (8 bits)
     * we don't care for button status that we get, especially on release, so
     * drop them */
    ev->state &= 0x00ff;

    if((wibox = wibox_getbywin(ev->event))
       || (wibox = wibox_getbywin(ev->child)))
    {
        /* If the wibox is child, then x,y are
         * relative to root window */
        if(wibox->window == ev->child)
        {
            ev->event_x -= wibox->geometry.x;
            ev->event_y -= wibox->geometry.y;
        }

        luaA_object_push(globalconf.L, wibox);
        event_button_callback(ev, &wibox->buttons, -1, 1, NULL);

        /* then try to match a widget binding */
        widget_t *w = widget_getbycoords(wibox->orientation, &wibox->widgets,
                                         wibox->geometry.width,
                                         wibox->geometry.height,
                                         &ev->event_x, &ev->event_y);
        if(w)
        {
            luaA_object_push(globalconf.L, w);
            luaA_object_push(globalconf.L, wibox);
            event_button_callback(ev, &w->buttons, -2, 2, NULL);
        }
    }
    else if((c = client_getbywin(ev->event)))
    {
        LOGDBG("nofocus %d\n", c->nofocus);
#ifdef LAB126
        /* make sure signalHandled inits to false*/
        /* signal handling callback in lua will store result here*/
        c->signalHandled = false;
#endif
        luaA_object_push(globalconf.L, c);
        event_button_callback(ev, &c->buttons, -1, 1, NULL);

#ifdef LAB126 
        LOGDBG("c->signalHandled = %d \n", c->signalHandled);

        /* if LUA did not handled event send on to client*/
        /* otherwise eat the event*/
        if (!c->signalHandled){

            LOGDBG("+++++ event_handle_button resending non handled event to %p\n", c->window);
#ifdef LAB126
            wait_for_damage_from_client(c);
#endif

            /* NOTE a side effect of using replay pointer is that winmgr does not get the related events */
            /* after the button one down. In other words, if winmgr sends button 1 down onto the client, */
            /* the button 3 down/up and button 1 up are also automatically sent onto the client. If winmgr */
            /* requires the ability to subscribe directly to extended buttons, the option considered was to */
            /* to always use XCB_ALLOW_ASYNC_POINTER to eat the original event and then manually copy and */
            /* resend the event. Also note that to do this winmgr will need to start forwading motion events */
            /* as well. */ 
            xcb_allow_events(globalconf.connection,
                    XCB_ALLOW_REPLAY_POINTER,
                    ev->time);

        }
        else
        {
            LOGDBG("+++++ event_handle_button not resending handled event to %p\n", c->window);
            xcb_allow_events(globalconf.connection,
                    XCB_ALLOW_ASYNC_POINTER,
                    ev->time);
        }
        
        /* make sure key events are not being interrupted */
        /* even though the button grab is async originally */
        /* we see button/key events left in a bad state when they */
        /* happen in mixed order */
        xcb_allow_events(globalconf.connection,
                    XCB_ALLOW_ASYNC_KEYBOARD,
                    ev->time);
        xcb_flush(globalconf.connection);
#else
        xcb_allow_events(globalconf.connection,
                         XCB_ALLOW_REPLAY_POINTER,
                         XCB_CURRENT_TIME);
#endif

#ifdef LOGGING_PERF
        /*perf log the event processing*/
        struct timeval timeEnd;
        int delay;

        /* get end timestamp */
        gettimeofday(&timeEnd, NULL);

        /* calculate time different in milliseconds */
        delay = (timeEnd.tv_sec - timeStart.tv_sec) * 1000 + (timeEnd.tv_usec - timeStart.tv_usec) / 1000;

        /* log start time and total time */
        LOGDBG("=====button event grab -- time=%d.%06d delay=%d\n", (int)timeStart.tv_sec, (int)timeStart.tv_usec, delay );
#endif

    }
    else if(ev->child == XCB_NONE)
        for(screen = 0; screen < nb_screen; screen++)
            if(xutil_screen_get(connection, screen)->root == ev->event)
            {
                event_button_callback(ev, &globalconf.buttons, 0, 0, NULL);
                return 0;
            }

    return 0;
}

static void
event_handle_configurerequest_configure_window(xcb_configure_request_event_t *ev)
{
    uint16_t config_win_mask = 0;
    uint32_t config_win_vals[7];
    unsigned short i = 0;

    if(ev->value_mask & XCB_CONFIG_WINDOW_X)
    {
        config_win_mask |= XCB_CONFIG_WINDOW_X;
        config_win_vals[i++] = ev->x;
    }
    if(ev->value_mask & XCB_CONFIG_WINDOW_Y)
    {
        config_win_mask |= XCB_CONFIG_WINDOW_Y;
        config_win_vals[i++] = ev->y;
    }
    if(ev->value_mask & XCB_CONFIG_WINDOW_WIDTH)
    {
        config_win_mask |= XCB_CONFIG_WINDOW_WIDTH;
        config_win_vals[i++] = ev->width;
    }
    if(ev->value_mask & XCB_CONFIG_WINDOW_HEIGHT)
    {
        config_win_mask |= XCB_CONFIG_WINDOW_HEIGHT;
        config_win_vals[i++] = ev->height;
    }
    if(ev->value_mask & XCB_CONFIG_WINDOW_BORDER_WIDTH)
    {
        config_win_mask |= XCB_CONFIG_WINDOW_BORDER_WIDTH;
        config_win_vals[i++] = ev->border_width;
    }
    if(ev->value_mask & XCB_CONFIG_WINDOW_SIBLING)
    {
        config_win_mask |= XCB_CONFIG_WINDOW_SIBLING;
        config_win_vals[i++] = ev->sibling;
    }
    if(ev->value_mask & XCB_CONFIG_WINDOW_STACK_MODE)
    {
        config_win_mask |= XCB_CONFIG_WINDOW_STACK_MODE;
        config_win_vals[i++] = ev->stack_mode;
    }

    xcb_configure_window(globalconf.connection, ev->window, config_win_mask, config_win_vals);
}

/** The configure event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_configurerequest(void *data __attribute__ ((unused)),
                              xcb_connection_t *connection, xcb_configure_request_event_t *ev)
{
    client_t *c;
    area_t geometry;

    if((c = client_getbywin(ev->window)))
    {
        geometry = titlebar_geometry_remove(c->titlebar, c->border_width, c->geometry);

        if(ev->value_mask & XCB_CONFIG_WINDOW_X)
            geometry.x = ev->x;
        if(ev->value_mask & XCB_CONFIG_WINDOW_Y)
            geometry.y = ev->y;
        if(ev->value_mask & XCB_CONFIG_WINDOW_WIDTH)
            geometry.width = ev->width;
        if(ev->value_mask & XCB_CONFIG_WINDOW_HEIGHT)
            geometry.height = ev->height;

        if(ev->value_mask & XCB_CONFIG_WINDOW_BORDER_WIDTH)
        {
            luaA_object_push(globalconf.L, c);
            client_set_border_width(globalconf.L, -1, ev->border_width);
            lua_pop(globalconf.L, 1);
        }

        /* Clients are not allowed to directly mess with stacking parameters. */
        ev->value_mask &= ~(XCB_CONFIG_WINDOW_SIBLING |
                                            XCB_CONFIG_WINDOW_STACK_MODE);

        /** Configure request are sent with size relative to real (internal)
         * window size, i.e. without titlebars and borders. */
        geometry = titlebar_geometry_add(c->titlebar, c->border_width, geometry);

        if(!client_resize(c, geometry, false))
        {
            /* Resize wasn't officially needed, but we don't want to break expectations. */
            geometry = titlebar_geometry_remove(c->titlebar, c->border_width, c->geometry);
            window_configure(c->window, geometry, c->border_width);
        }
    }
    else
        event_handle_configurerequest_configure_window(ev);

    return 0;
}

/** The configure notify event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_configurenotify(void *data __attribute__ ((unused)),
                             xcb_connection_t *connection, xcb_configure_notify_event_t *ev)
{
    int screen_nbr;
    const xcb_screen_t *screen;

#ifdef LAB126
    /* As XRandR event is not generated, handle screen rotation here
     * TODO: Revisit once XRandR is available
     */
    for(screen_nbr = 0; screen_nbr < xcb_setup_roots_length(xcb_get_setup (connection)); screen_nbr++)
        if((screen = xutil_screen_get(connection, screen_nbr)) != NULL
           && ev->window == screen->root)
        {
            /* Instead of tearing down everything, change screen size and generate signal */
            screen_size_set(screen_nbr, ev->width, ev->height, "rotate");
        }
#else
    for(screen_nbr = 0; screen_nbr < xcb_setup_roots_length(xcb_get_setup (connection)); screen_nbr++)
        if((screen = xutil_screen_get(connection, screen_nbr)) != NULL
           && ev->window == screen->root
           && (ev->width != screen->width_in_pixels
               || ev->height != screen->height_in_pixels))
            /* it's not that we panic, but restart */
            awesome_restart();
#endif
    return 0;
}

/** The destroy notify event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_destroynotify(void *data __attribute__ ((unused)),
                           xcb_connection_t *connection __attribute__ ((unused)),
                           xcb_destroy_notify_event_t *ev)
{
    client_t *c;

    if((c = client_getbywin(ev->window))) {
#ifdef LAB126
        stop_waiting_for_client_response(c);
#endif
        client_unmanage(c);
    }
    else
        for(int i = 0; i < globalconf.embedded.len; i++)
            if(globalconf.embedded.tab[i].win == ev->window)
            {
                xembed_window_array_take(&globalconf.embedded, i);
                widget_invalidate_bytype(widget_systray);
            }

    return 0;
}

/** Handle a motion notify over widgets.
 * \param object The object.
 * \param mouse_over The pointer to the registered mouse over widget.
 * \param widget The new widget the mouse is over.
 */
static void
event_handle_widget_motionnotify(void *object,
                                 widget_t **mouse_over,
                                 widget_t *widget)
{
    if(widget != *mouse_over)
    {
        if(*mouse_over)
        {
            /* call mouse leave function on old widget */
            luaA_object_push(globalconf.L, *mouse_over);
            luaA_object_emit_signal(globalconf.L, -1, "mouse::leave", 0);
            lua_pop(globalconf.L, 1);

            luaA_object_unref(globalconf.L, *mouse_over);
            *mouse_over = NULL;
        }
        if(widget)
        {
            /* Get a ref on this widget so that it can't be unref'd from
             * underneath us (-> invalid pointer dereference). */
            luaA_object_push(globalconf.L, widget);
            luaA_object_ref(globalconf.L, -1);
            *mouse_over = widget;

            /* emit mouse::enter signal on new widget */
            luaA_object_push(globalconf.L, widget);
            luaA_object_emit_signal(globalconf.L, -1, "mouse::enter", 0);
            lua_pop(globalconf.L, 1);
        }
    }
}

/** The motion notify event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_motionnotify(void *data __attribute__ ((unused)),
                          xcb_connection_t *connection,
                          xcb_motion_notify_event_t *ev)
{
    wibox_t *wibox;

    if(event_handle_mousegrabber(ev->root_x, ev->root_y, ev->state))
        return 0;

    if((wibox = wibox_getbywin(ev->event)))
    {
        widget_t *w = widget_getbycoords(wibox->orientation, &wibox->widgets,
                                         wibox->geometry.width,
                                         wibox->geometry.height,
                                         &ev->event_x, &ev->event_y);
        if(w)
            event_handle_widget_motionnotify(wibox, &wibox->mouse_over, w);
    }

    return 0;
}

/** The leave notify event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_leavenotify(void *data __attribute__ ((unused)),
                         xcb_connection_t *connection,
                         xcb_leave_notify_event_t *ev)
{
    wibox_t *wibox;
    client_t *c;

    if(ev->mode != XCB_NOTIFY_MODE_NORMAL)
        return 0;

    if((c = client_getbytitlebarwin(ev->event)) || (c = client_getbywin(ev->event)))
    {
        if(globalconf.hooks.mouse_leave != LUA_REFNIL)
        {
            luaA_object_push(globalconf.L, c);
            luaA_dofunction_from_registry(globalconf.L, globalconf.hooks.mouse_leave, 1, 0);
        }
        luaA_object_push(globalconf.L, c);
        luaA_object_emit_signal(globalconf.L, -1, "mouse::leave", 0);
        lua_pop(globalconf.L, 1);
    }

    if((wibox = wibox_getbywin(ev->event)))
    {
        if(wibox->mouse_over)
        {
            luaA_object_push(globalconf.L, wibox->mouse_over);
            /* emit mouse::leave signal on widget the mouse was over */
            luaA_object_emit_signal(globalconf.L, -1, "mouse::leave", 0);
            lua_pop(globalconf.L, 1);
            wibox_clear_mouse_over(wibox);
        }

        luaA_object_push(globalconf.L, wibox);
        luaA_object_emit_signal(globalconf.L, -1, "mouse::leave", 0);
        lua_pop(globalconf.L, 1);
    }

    return 0;
}

/** The enter notify event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_enternotify(void *data __attribute__ ((unused)),
                         xcb_connection_t *connection,
                         xcb_enter_notify_event_t *ev)
{
    client_t *c;
    wibox_t *wibox;

    if(ev->mode != XCB_NOTIFY_MODE_NORMAL)
        return 0;

    if((wibox = wibox_getbywin(ev->event)))
    {
        widget_t *w = widget_getbycoords(wibox->orientation, &wibox->widgets,
                                         wibox->geometry.width,
                                         wibox->geometry.height,
                                         &ev->event_x, &ev->event_y);
        if(w)
            event_handle_widget_motionnotify(wibox, &wibox->mouse_over, w);

        luaA_object_push(globalconf.L, wibox);
        luaA_object_emit_signal(globalconf.L, -1, "mouse::enter", 0);
        lua_pop(globalconf.L, 1);
    }

    if((c = client_getbytitlebarwin(ev->event))
       || (c = client_getbywin(ev->event)))
    {
        if(globalconf.hooks.mouse_enter != LUA_REFNIL)
        {
            luaA_object_push(globalconf.L, c);
            luaA_dofunction_from_registry(globalconf.L, globalconf.hooks.mouse_enter, 1, 0);
        }
        luaA_object_push(globalconf.L, c);
        luaA_object_emit_signal(globalconf.L, -1, "mouse::enter", 0);
        lua_pop(globalconf.L, 1);


/* switched to using button 1 clicks rather than mouse enter, but leaving code for now*/
/* in case I need to go back*/
/*#ifdef LAB126*/
#if 0
        /*it may be useful to change the above luaA_object_emit_signal to the below*/
        /*the diff being that the below is not a specific client object, but sends */
        /*on any client and makes it easy to pick up mouse::enter on any client from */
        /*the LUA level*/
        /*luaA_class_emit_signal(globalconf.L, &client_class, "mouse::enter", 1);*/

        /*If this client accepts focus, give it focus*/
        /*this may not be needed once we get mouse clicks rather than enternotify*/
        /*on tap into a new window*/
        if (c->nofocus){
            LOGDBG("enternotify - moused win does not accept focus\n");
        } else {
            LOGDBG("enternotify - setting focus to moused client\n");
            client_set_focus(c, true);
        }
#endif

    }


    return 0;
}

/** The focus in event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_focusin(void *data __attribute__ ((unused)),
                     xcb_connection_t *connection,
                     xcb_focus_in_event_t *ev)
{
    client_t *c;

    /* Events that we are interested in: */
    switch(ev->detail)
    {
        /* These are events that jump between root windows.
         */
        case XCB_NOTIFY_DETAIL_ANCESTOR:
        case XCB_NOTIFY_DETAIL_INFERIOR:

        /* These are events that jump between clients.
         * Virtual events ensure we always get an event on our top-level window.
         */
        case XCB_NOTIFY_DETAIL_NONLINEAR_VIRTUAL:
        case XCB_NOTIFY_DETAIL_NONLINEAR:
            if((c = client_getbytitlebarwin(ev->event))
               || (c = client_getbywin(ev->event)))
                client_focus_update(c);
        /* all other events are ignored */
        default:
            break;
    }
    return 0;
}

/** The expose event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_expose(void *data __attribute__ ((unused)),
                    xcb_connection_t *connection __attribute__ ((unused)),
                    xcb_expose_event_t *ev)
{
    wibox_t *wibox;

    /* If the wibox got need_update set, skip this because it will be repainted
     * soon anyway. Without this we could be painting garbage to the screen!
     */
    if((wibox = wibox_getbywin(ev->window)) && !wibox->need_update)
        wibox_refresh_pixmap_partial(wibox,
                                     ev->x, ev->y,
                                     ev->width, ev->height);

    return 0;
}

/** The key press event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_key(void *data __attribute__ ((unused)),
                 xcb_connection_t *connection __attribute__ ((unused)),
                 xcb_key_press_event_t *ev)
{
    LOGDBG("+++++event_handle_key %d, %d, %d, %d, %d\n", ev->detail, ev->state, ev->response_type,
                ev->time, ev->sequence);

    if(globalconf.keygrabber != LUA_REFNIL)
    {
        lua_rawgeti(globalconf.L, LUA_REGISTRYINDEX, globalconf.keygrabber);
        if(keygrabber_handlekpress(globalconf.L, ev))
        {
            if(lua_pcall(globalconf.L, 3, 1, 0))
            {
                warn("error running function: %s", lua_tostring(globalconf.L, -1));
                luaA_keygrabber_stop(globalconf.L);
            }
            else if(!lua_isboolean(globalconf.L, -1) || !lua_toboolean(globalconf.L, -1))
                luaA_keygrabber_stop(globalconf.L);
        }
        lua_pop(globalconf.L, 1);  /* pop returned value or function if not called */
    }
    else
    {
        /* get keysym ignoring all modifiers */
        xcb_keysym_t keysym = key_getkeysym(ev->detail, 0);
        client_t *c;
        if((c = client_getbywin(ev->event)))
        {

#ifdef LAB126
            /* make sure signalHandled inits to false*/
            /* signal handling callback in lua will store result here*/
            c->signalHandled = false;
#endif

            luaA_object_push(globalconf.L, c);
            lua_pushnumber(globalconf.L, ev->response_type);
            lua_pushnumber(globalconf.L, ev->detail);
            lua_pushnumber(globalconf.L, ev->state);
            event_key_callback(ev, &c->keys, -4, 4, &keysym);
#ifdef LAB126
            LOGDBG("c->signalHandled = %d \n", c->signalHandled);

            /* if LUA did not handled event send on to client*/
            /*otherwise eat the event*/
            if (!c->signalHandled){
            	LOGDBG("+++++event_handle_key resending non handled event to %p\n", c->window);
            	
            	/* REPLAY event is not working. Thus re sending the event again */
            	int keyMask = ev->response_type == XCB_KEY_PRESS?XCB_EVENT_MASK_KEY_PRESS:XCB_EVENT_MASK_KEY_RELEASE;
            	xcb_send_event(globalconf.connection, true, c->window, keyMask, (const char*)ev);
            	
            	/* still eat and force send until I figure out why prev is getting corrupt */
                xcb_allow_events(globalconf.connection,
                                 XCB_ALLOW_ASYNC_KEYBOARD,
                                 ev->time);
                                 
            	/* prev is getting corrupt if I replay the keyboard event */
            	/* adding a separate task to go evaluate this problem */
            	//xcb_allow_events(globalconf.connection,
                //    XCB_ALLOW_REPLAY_KEYBOARD,
                //    ev->time);
            }
            else
            {
                LOGDBG("+++++event_handle_key not resending on handled event to  %p\n", c->window);
                xcb_allow_events(globalconf.connection,
                                 XCB_ALLOW_ASYNC_KEYBOARD,
                                 ev->time);
            }
            
            /* make sure pointer events are not being interrupted */
            /* even though the button grab is async originally */
            /* we see button/key events left in a bad state when they */
            /* happen in mixed order */
            xcb_allow_events(globalconf.connection,
                    XCB_ALLOW_ASYNC_POINTER,
                    ev->time);
                    
            xcb_flush(globalconf.connection);
#endif
        }
        else
            event_key_callback(ev, &globalconf.keys, 0, 0, &keysym);
    }

    return 0;
}

/** The map request event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_maprequest(void *data __attribute__ ((unused)),
                        xcb_connection_t *connection, xcb_map_request_event_t *ev)
{
    int phys_screen, ret = 0;
    client_t *c;
    xcb_get_window_attributes_cookie_t wa_c;
    xcb_get_window_attributes_reply_t *wa_r;
    xcb_get_geometry_cookie_t geom_c;
    xcb_get_geometry_reply_t *geom_r;

    wa_c = xcb_get_window_attributes_unchecked(connection, ev->window);

    if(!(wa_r = xcb_get_window_attributes_reply(connection, wa_c, NULL)))
        return -1;

    if(wa_r->override_redirect)
        goto bailout;

    if(xembed_getbywin(&globalconf.embedded, ev->window))
    {
        xcb_map_window(connection, ev->window);
        xembed_window_activate(connection, ev->window);
    }
    else if((c = client_getbywin(ev->window)))
    {
        /* Check that it may be visible, but not asked to be hidden */
        if(client_maybevisible(c, c->screen) && !c->hidden)
        {
            luaA_object_push(globalconf.L, c);
            client_set_minimized(globalconf.L, -1, false);
            lua_pop(globalconf.L, 1);
            /* it will be raised, so just update ourself */
            client_raise(c);

            /*forcing a map for lab126 builds*/
#ifdef LAB126
            /* removing the XCB_EVENT_SENT(ev) check */
            /* in unmap means that this path will not be */
            /* hit as much. */
            xcb_map_window(connection, ev->window);
#endif
        }
    }
    else
    {
        geom_c = xcb_get_geometry_unchecked(connection, ev->window);

        if(!(geom_r = xcb_get_geometry_reply(connection, geom_c, NULL)))
        {
            ret = -1;
            goto bailout;
        }

        phys_screen = xutil_root2screen(connection, geom_r->root);

        client_manage(ev->window, geom_r, phys_screen, false);

        p_delete(&geom_r);
    }

bailout:
    p_delete(&wa_r);
    return ret;
}

/** The unmap notify event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_unmapnotify(void *data __attribute__ ((unused)),
                         xcb_connection_t *connection, xcb_unmap_notify_event_t *ev)
{
    client_t *c;

    if((c = client_getbywin(ev->window)))
    {
#ifdef LAB126
        stop_waiting_for_client_response(c);
#endif

        if(ev->event == xutil_screen_get(connection, c->phys_screen)->root
                /*turning XCB_EVENT_SENT check off for lab126 builds*/
                /*because it is not firing when windows are unmapped which*/
                /*results in the LUA script missing a re-tile opportunity*/
#ifdef LAB126
           && window_state_get_reply(window_state_get_unchecked(c->window), NULL) == XCB_WM_STATE_NORMAL)
#else
           && XCB_EVENT_SENT(ev)
           && window_state_get_reply(window_state_get_unchecked(c->window)) == XCB_WM_STATE_NORMAL)
#endif
           client_unmanage(c);
    }
    else
        for(int i = 0; i < globalconf.embedded.len; i++)
            if(globalconf.embedded.tab[i].win == ev->window)
            {
                xembed_window_array_take(&globalconf.embedded, i);
                widget_invalidate_bytype(widget_systray);
            }

    return 0;
}

/** The randr screen change notify event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_randr_screen_change_notify(void *data __attribute__ ((unused)),
                                        xcb_connection_t *connection __attribute__ ((unused)),
                                        xcb_randr_screen_change_notify_event_t *ev)
{
    /* Code  of  XRRUpdateConfiguration Xlib  function  ported to  XCB
     * (only the code relevant  to RRScreenChangeNotify) as the latter
     * doesn't provide this kind of function */
    if(ev->rotation & (XCB_RANDR_ROTATION_ROTATE_90 | XCB_RANDR_ROTATION_ROTATE_270))
        xcb_randr_set_screen_size(connection, ev->root, ev->height, ev->width,
                                  ev->mheight, ev->mwidth);
    else
        xcb_randr_set_screen_size(connection, ev->root, ev->width, ev->height,
                                  ev->mwidth, ev->mheight);

    /* XRRUpdateConfiguration also executes the following instruction
     * but it's not useful because SubpixelOrder is not used at all at
     * the moment
     *
     * XRenderSetSubpixelOrder(dpy, snum, scevent->subpixel_order);
     */
   
    awesome_restart();
    
    return 0;
}

#ifdef LAB126
static int
event_handle_damage_notify(void *data __attribute__ ((unused)),
                                        xcb_connection_t *connection __attribute__ ((unused)),
                                        xcb_damage_notify_event_t *ev)
{
    client_t* c;
    area_t area;

    xcb_damage_subtract(connection, ev->damage, XCB_XFIXES_REGION_NONE, XCB_XFIXES_REGION_NONE);
    xcb_flush(connection);
    if ((c = client_getbywin(ev->drawable))) {
#ifdef LAB126
        stop_waiting_for_client_response(c);
#endif
        area.x = ev->area.x;
        area.y = ev->area.y;
        area.width = ev->area.width;
        area.height = ev->area.height;
        client_damage(c, area);
    }
    else {
        int phys_screen;

        // if it's a root
        for(phys_screen = 0; phys_screen < globalconf.screens.len; phys_screen++)
        {
            if (xutil_screen_get(globalconf.connection, phys_screen)->root == ev->drawable) {
                lua_pushinteger(globalconf.L, ev->area.x);
                lua_pushinteger(globalconf.L, ev->area.y);
                lua_pushinteger(globalconf.L, ev->area.width);
                lua_pushinteger(globalconf.L, ev->area.height);
                screen_emit_signal(globalconf.L,
                        &globalconf.screens.tab[phys_screen], "damage", 4);
                break;
            }
        }
    }
    return 0;
}
#endif

#ifdef LAB126
/**
 * look for custom client messages
 * @params connection   : xcb connection
 * @params ev           : client message event
 * @return  0 if not handled by client, otherwise 1
 */
static int
event_handle_custom_clientmessage(xcb_connection_t *connection,
        xcb_client_message_event_t *ev){

    int returnVal = 0;

    client_t *c;
    if ((c = client_getbywin(ev->window))){

        LOGDBG("check client message for %p", ev->window);

        /* get atom name string */
        xcb_get_atom_name_cookie_t atom_name_cookie = xcb_get_atom_name_unchecked(connection, ev->type);
        xcb_get_atom_name_reply_t * atom_name_reply = xcb_get_atom_name_reply (connection,
                atom_name_cookie, NULL);
        if (atom_name_reply){

            /* xcb_get_atom_name_name does not appear to allocate mem */
            /* the string is not null terminated */
            char * atomName = xcb_get_atom_name_name (atom_name_reply);
            int atomNameLen = xcb_get_atom_name_name_length(atom_name_reply);

            /* check client to see if handled by scripts*/
            returnVal = client_message(c, atomName, atomNameLen, ev->data.data8);

            free(atom_name_reply);
        }
    } else {
        LOGINFO("client message on non managed window");
    }

    return returnVal;
}

#endif

/** The client message event handler.
 * \param data currently unused.
 * \param connection The connection to the X server.
 * \param ev The event.
 */
static int
event_handle_clientmessage(void *data __attribute__ ((unused)),
                           xcb_connection_t *connection,
                           xcb_client_message_event_t *ev)
{
    LOGDBG("client message event");
    
    /* check for startup notification messages */
    if(sn_xcb_display_process_event(globalconf.sndisplay, (xcb_generic_event_t *) ev))
        return 0;

    if(ev->type == WM_CHANGE_STATE)
    {
        client_t *c;
        if((c = client_getbywin(ev->window))
           && ev->format == 32
           && ev->data.data32[0] == XCB_WM_STATE_ICONIC)
        {
            luaA_object_push(globalconf.L, c);
            client_set_minimized(globalconf.L, -1, true);
            lua_pop(globalconf.L, 1);
        }
    }
    else if(ev->type == _XEMBED)
        return xembed_process_client_message(ev);
    else if(ev->type == _NET_SYSTEM_TRAY_OPCODE)
        return systray_process_client_message(ev);
#ifdef LAB126
    else if(ev->type == WM_PROTOCOLS && ev->data.data32[0] == _NET_WM_PING) {
        //Process pong from client
        process_wm_pong(ev);
        return 0;
    }
#endif

#ifdef LAB126
    /* look for custom client messages */
    if (event_handle_custom_clientmessage(connection, ev)){
        return 0;
    }
#endif

    return ewmh_process_client_message(ev);
}

/** The keymap change notify event handler.
 * \param data Unused data.
 * \param connection The connection to the X server.
 * \param ev The event.
 * \return Status code, 0 if everything's fine.
 */
static int
event_handle_mappingnotify(void *data,
                           xcb_connection_t *connection,
                           xcb_mapping_notify_event_t *ev)
{
    if(ev->request == XCB_MAPPING_MODIFIER
       || ev->request == XCB_MAPPING_KEYBOARD)
    {
        xcb_get_modifier_mapping_cookie_t xmapping_cookie =
            xcb_get_modifier_mapping_unchecked(globalconf.connection);

        /* Free and then allocate the key symbols */
        xcb_key_symbols_free(globalconf.keysyms);
        globalconf.keysyms = xcb_key_symbols_alloc(globalconf.connection);

        xutil_lock_mask_get(globalconf.connection, xmapping_cookie,
                            globalconf.keysyms, &globalconf.numlockmask,
                            &globalconf.shiftlockmask, &globalconf.capslockmask,
                            &globalconf.modeswitchmask);

        int nscreen = xcb_setup_roots_length(xcb_get_setup(connection));

        /* regrab everything */
        for(int phys_screen = 0; phys_screen < nscreen; phys_screen++)
        {
            xcb_screen_t *s = xutil_screen_get(globalconf.connection, phys_screen);
            /* yes XCB_BUTTON_MASK_ANY is also for grab_key even if it's look weird */
            xcb_ungrab_key(connection, XCB_GRAB_ANY, s->root, XCB_BUTTON_MASK_ANY);
            window_grabkeys(s->root, &globalconf.keys);
        }

        foreach(_c, globalconf.clients)
        {
            client_t *c = *_c;
            xcb_ungrab_key(connection, XCB_GRAB_ANY, c->window, XCB_BUTTON_MASK_ANY);
            window_grabkeys(c->window, &c->keys);
        }
    }

    return 0;
}

static int
event_handle_reparentnotify(void *data,
                           xcb_connection_t *connection,
                           xcb_reparent_notify_event_t *ev)
{
    client_t *c;

    if((c = client_getbywin(ev->window))) {
#ifdef LAB126
        stop_waiting_for_client_response(c);
#endif
        client_unmanage(c);
    }

    return 0;
}

void a_xcb_set_event_handlers(void)
{
    xcb_event_set_button_press_handler(&globalconf.evenths, event_handle_button, NULL);
    xcb_event_set_button_release_handler(&globalconf.evenths, event_handle_button, NULL);
    xcb_event_set_configure_request_handler(&globalconf.evenths, event_handle_configurerequest, NULL);
    xcb_event_set_configure_notify_handler(&globalconf.evenths, event_handle_configurenotify, NULL);
    xcb_event_set_destroy_notify_handler(&globalconf.evenths, event_handle_destroynotify, NULL);
    xcb_event_set_enter_notify_handler(&globalconf.evenths, event_handle_enternotify, NULL);
    xcb_event_set_leave_notify_handler(&globalconf.evenths, event_handle_leavenotify, NULL);
    xcb_event_set_focus_in_handler(&globalconf.evenths, event_handle_focusin, NULL);
    xcb_event_set_motion_notify_handler(&globalconf.evenths, event_handle_motionnotify, NULL);
    xcb_event_set_expose_handler(&globalconf.evenths, event_handle_expose, NULL);
    xcb_event_set_key_press_handler(&globalconf.evenths, event_handle_key, NULL);
    xcb_event_set_key_release_handler(&globalconf.evenths, event_handle_key, NULL);
    xcb_event_set_map_request_handler(&globalconf.evenths, event_handle_maprequest, NULL);
    xcb_event_set_unmap_notify_handler(&globalconf.evenths, event_handle_unmapnotify, NULL);
    xcb_event_set_client_message_handler(&globalconf.evenths, event_handle_clientmessage, NULL);
    xcb_event_set_mapping_notify_handler(&globalconf.evenths, event_handle_mappingnotify, NULL);
    xcb_event_set_reparent_notify_handler(&globalconf.evenths, event_handle_reparentnotify, NULL);

#ifdef LAB126
    WMFreezeDetectionMgr = g_hash_table_new_full(g_direct_hash, g_direct_equal, NULL, free_freeze_detection_data);
#endif

    /* check for randr extension */
#ifdef LAB126
/*  const xcb_query_extension_reply_t* randr_query =
        xcb_get_extension_data(globalconf.connection, &xcb_randr_id);
    if(randr_query->present)
    {
        xcb_event_set_handler(&globalconf.evenths,
                              randr_query->first_event + XCB_RANDR_SCREEN_CHANGE_NOTIFY,
                              (xcb_generic_event_handler_t) event_handle_randr_screen_change_notify,
                              NULL);
    }*/

    const xcb_query_extension_reply_t *damage_query =
                xcb_get_extension_data(globalconf.connection, &xcb_damage_id);
    if (damage_query && damage_query->present) {
        xcb_damage_query_version_cookie_t version_cookie =
                xcb_damage_query_version_unchecked(globalconf.connection, 1, 1);
        xcb_damage_query_version_reply_t *reply =
                xcb_damage_query_version_reply(globalconf.connection, version_cookie, NULL);

        if (reply)
        {
            if (reply->major_version >= 1) {
                // damage available
                xcb_event_set_handler(&globalconf.evenths,
                                              damage_query->first_event + XCB_DAMAGE_NOTIFY,
                                              (xcb_generic_event_handler_t) event_handle_damage_notify,
                                              NULL);
            }

            free(reply);
        }
    }

#endif
}

// vim: filetype=c:expandtab:shiftwidth=4:tabstop=8:softtabstop=4:encoding=utf-8:textwidth=80

/***************************************************************************
 *
 * Multitouch X driver
 * Copyright (C) 2008 Henrik Rydberg <rydberg@euromail.se>
 *
 * Gestures
 * Copyright (C) 2008 Henrik Rydberg <rydberg@euromail.se>
 * Copyright (C) 2010 Arturo Castro <mail@arturocastro.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 **************************************************************************/

#include "gestures.h"
#include <math.h>

static const int FINGER_THUMB_MS = 600;

#define RADIAN_TO_DEGREE(x) ((x) * 57.295779513)

/**
 * extract_buttons
 *
 * Set the button gesture.
 *
 * Reset memory after use.
 *
 */
static void extract_buttons(struct Gestures *gs, struct MTouch* mt)
{
  gs->btmask = 0;
  mt->mem.btdata = 0;
}

/**
 * extract_movement
 *
 * Set the movement gesture.
 *
 * Reset memory after use.
 *
 */
static void extract_movement(struct Gestures *gs, struct MTouch* mt)
{
  int npoint = bitcount(mt->mem.pointing);
  int nmove = bitcount(mt->mem.moving);
  int nFingers = bitcount(mt->mem.fingers);
  int i;
  float xp[DIM_FINGER], yp[DIM_FINGER];
  float xm[DIM_FINGER], ym[DIM_FINGER];
  float xabs[DIM_FINGER], yabs[DIM_FINGER];
  float absDist = 0;
  int   absIdx = 0;
  float xpos = 0, ypos = 0;
  float move, xmove = 0, ymove = 0;

  if (mt->state.nfinger == 2 && mt->options.screenshot)
  {
    int minx = minval(mt->state.finger[0].position_x, mt->state.finger[1].position_x);
    int maxx = maxval(mt->state.finger[0].position_x, mt->state.finger[1].position_x);
    int miny = minval(mt->state.finger[0].position_y, mt->state.finger[1].position_y);
    int maxy = maxval(mt->state.finger[0].position_y, mt->state.finger[1].position_y);

    if (minx < 100 && (maxx > (get_cap_xsize(&mt->caps) - 100)) &&
        miny < 100 && (maxy > (get_cap_ysize(&mt->caps) - 100)))
    {
      SETBIT(gs->type, GS_SCREENSHOT);
      return;
    }
  }

  if (npoint > 2 || !npoint)
    return;

  foreach_bit(i, mt->mem.pointing) {
    xabs[absIdx] = mt->state.finger[i].position_x;
    yabs[absIdx++] = mt->state.finger[i].position_y;
    xp[i] = mt->state.finger[i].position_x - xpos;
    yp[i] = mt->state.finger[i].position_y - ypos;
    xm[i] = mt->mem.dx[i];
    ym[i] = mt->mem.dy[i];
    mt->mem.dx[i] = 0;
    mt->mem.dy[i] = 0;
    xpos += xp[i];
    ypos += yp[i];
    xmove += xm[i];
    ymove += ym[i];
  }
  xpos /= (float)npoint;
  ypos /= (float)npoint;
  xmove /= (float)npoint;
  ymove /= (float)npoint;
  move = sqrt(xmove * xmove + ymove * ymove);

  if (absIdx == 2)
  {
    int minx, maxx;
    int miny, maxy;
    float absDistX = (float)(xabs[1] - xabs[0]) * mt->options.size_x_mm / (float)get_cap_xsize(&mt->caps);
    float absDistY = (float)(yabs[1] - yabs[0]) * mt->options.size_y_mm / (float)get_cap_ysize(&mt->caps);
    absDist = sqrt(absDistX*absDistX + absDistY*absDistY);
    xpos = (xabs[0] + xabs[1]) / 2;
    ypos = (yabs[0] + yabs[1]) / 2;
  }


  gs->x  = xpos;
  gs->y  = ypos;
  gs->dx = xmove;
  gs->dy = ymove;


  if (gs->dx || gs->dy)
  {
    SETBIT(gs->type, GS_MOVE);
    if (npoint <= 2) {
      float angleX = 0.0f;
      float angleY = 90.0f;
      if (mt->mem.ydown - gs->y)
      {
        angleX = atanf((float)(gs->y - (float)mt->mem.ydown) /
            (float)(gs->x - (float)mt->mem.xdown));
        angleX = fabs(RADIAN_TO_DEGREE(angleX));
      }
      angleY -= angleX;

      gs->distance = absDist;
      if (angleY < mt->options.vswipe_angle)
      {
        SETBIT(gs->type, GS_VSWIPE);
      }
      else
        SETBIT(gs->type, GS_HSWIPE);

      if (npoint == 2)
        SETBIT(gs->type, GS_SCALE);
    }
  }
}

/**
 * extract_gestures
 *
 * Extract the gestures.
 *
 * Reset memory after use.
 *
 */
void extract_gestures(struct Gestures *gs, struct MTouch* mt)
{
  memset(gs, 0, sizeof(struct Gestures));
  gs->same_fingers = mt->mem.same;
  extract_buttons(gs, mt);
  extract_movement(gs, mt);
}

/**
 * extract_delayed_gestures
 *
 * Extract delayed gestures, such as tapping
 *
 * Reset memory after use.
 *
 */
void extract_delayed_gestures(struct Gestures *gs, struct MTouch* mt)
{
  mt->mem.wait = 0;

  if (mt->mem.tpdown < mt->mem.tpup) {
    switch (mt->mem.maxtap) {
      case 1:
        gs->tapmask = BITMASK(MT_BUTTON_LEFT);
        break;
      case 2:
        gs->tapmask = BITMASK(MT_BUTTON_MIDDLE);
        break;
    }
  }

  if (gs->tapmask)
    SETBIT(gs->type, GS_TAP);

  gs->ntap = mt->mem.ntap;
}

void output_gesture(const struct Gestures *gs)
{
  int i;
  foreach_bit(i, gs->btmask)
    xf86Msg(X_INFO, "button bit: %d %d\n",
        i, GETBIT(gs->btdata, i));
  if (GETBIT(gs->type, GS_MOVE))
    xf86Msg(X_INFO, "motion: %d %d\n", gs->dx, gs->dy);
  if (GETBIT(gs->type, GS_VSWIPE))
    xf86Msg(X_INFO, "vswipe: %d\n", gs->dy);
  if (GETBIT(gs->type, GS_HSWIPE))
    xf86Msg(X_INFO, "hswipe: %d\n", gs->dx);
  if (GETBIT(gs->type, GS_SCALE))
    xf86Msg(X_INFO, "distance: %f\n", gs->distance);
  foreach_bit(i, gs->tapmask)
    xf86Msg(X_INFO, "tap: %d %d\n", i, gs->ntap);
}

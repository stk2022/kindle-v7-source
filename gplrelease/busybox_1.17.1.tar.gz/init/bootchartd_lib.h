long long boot_time_as_usecs_since_epoch(void);
